import simpy
import numpy as np

class Scheduler:
    def __init__(self, env, eqptype_name="", tools={}):
        self.env = env
        self.eqptype_name = eqptype_name
        self.tools = tools # {tool_name: Tool}

        self.reservation = []
        self.reservation_R = simpy.Resource(env, capacity=1)

        # self.dict_tool_to_recipes_to_MPU = {tool_name: tools[tool_name].dict_recp_to_MPU for tool_name in tools}
        # self.dict_tool2queue = {tool_name: [] for tool_name in tools}

        # self.dict_tool2queueResource = {tool_name: simpy.Resource(env, capacity=1) for tool_name in tools}


    def put_lot_into_reservation(self, lot_step_tuple):
        if lot_step_tuple not in self.reservation:
            self.reservation.append(lot_step_tuple)

    # default: FIFO
    def run(self):
        while True:
            if len(self.reservation) == 0:
                pass
            else:
                with self.reservation_R.request() as req:
                    yield req
                    while len(self.reservation) > 0:
                        lot, step_num = self.reservation.pop(0)
                        step = lot.valid_steps[step_num]
                        
                        try:
                            tools = [self.tools[tool_name] for tool_name in lot.dict_step_to_eqptype_to_tools[step][self.eqptype_name]]
                        except:
                            print(self.eqptype_name)
                            print(self.tools)
                            print(lot.dict_step_to_eqptype_to_tools[step][self.eqptype_name])
                            exit()
                        #TODO: 这里的 score 可能需要从 lot 自身的属性 dict_step_to_eqptype_to_mpu 中获取
                        tool_max = tools[np.argmax(np.array([et.score for et in tools]))]

                        with tool_max.queue_R.request() as req:
                            yield req
                            tool_max.queue.append((lot, step_num))
                            tool_max.update_score()
            yield self.env.timeout(0.25)




class Scheduler_FPSScheduler(Scheduler):
    def run(self):
        while True:
            # DO NOT run the scheduler IF Eqptype.reservation is empty
            if len(self.reservation) == 0:
                pass
            else:
                with self.reservation_R.request() as req:
                    yield req
                    # START scheduling
                    # (1) Clear all Tool.queue in Eqptype.tools
                    for et in self.tools.values():
                        with et.queue_R.request() as req:
                            yield req
                            self.reservation.extend(et.queue)
                            et.queue.clear()
                            et.update_score()

                    # (2) Update the score of all Lots & Entities
                    for lot, step_num in self.reservation:
                        lot.update_score(self.env)

                    # (3) Assignment
                    while len(self.reservation) > 0:
                        # Lot with the highest score (highest is the most ergent)
                        lotScores = np.array([lot.score for lot, step_num in self.reservation])
                        lot_max, step_num = self.reservation.pop(np.argmax(lotScores))
                        step = lot_max.valid_steps[step_num]

                        # Tool with the highest score (highest is the best-performed)
                        #   only the tools that could be used for the step of the maxLot
                        tools = [self.tools[tool_name] for tool_name in lot_max.dict_step_to_eqptype_to_tools[step][self.eqptype_name]]
                        # if len(tools) == 0:
                        #     raise ValueError("No tool is available for Lot {}'s step {}".format(maxLot.ID, step))
                        toolScores = np.array([et.score for et in tools])
                        tool_max = tools[np.argmax(np.array([et.score for et in tools]))]

                        # Assign Lot to Tool.queue
                        tool_max.queue.append((lot_max, step_num))
                        tool_max.update_score()

            # run scheduler every 15 minutes (0.25 hour)
            yield self.env.timeout(0.25)