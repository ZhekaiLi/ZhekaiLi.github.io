from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt
from mttkinter import mtTkinter as tk

from .TkUpdate_Main import TkUpdate_Main
from .TkUpdate_UtilizationPopup import TkUpdate_UtilizationPopup

import simpy



def tkinterGUI_popup(env, FAB, LOTS):
    top= tk.Toplevel()
    top.geometry("700x460")
    top.title("Utilization of PHOTO eqptype")

    fu, axs = plt.subplots(2, 2, figsize=(7, 2.4), dpi=72)

    axs[0, 0].set_yticks([])
    axs[0, 1].set_yticks([])
    axs[1, 0].set_yticks([])
    axs[1, 1].set_yticks([])

    plt.subplots_adjust(left=0.04, right=0.9, top=0.9, bottom=0.05)
    fu.tight_layout()

    figCanvas_utilization = FigureCanvasTkAgg(fu, master=top)
    figCanvas_utilization.get_tk_widget().config(height = 220)
    figCanvas_utilization.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

    # if not hasattr(top, 'canvas'):
    canvas = tk.Canvas(top, width=700, height=240, bg = "white")
    canvas.pack(side=tk.TOP, expand = True)

    tkUpdate = TkUpdate_UtilizationPopup(
        env=env, FAB=FAB, LOTS=LOTS,
        figCanvas_utilization=figCanvas_utilization, 
        axs=axs,
        canvas=canvas
    )

    process = env.process(tkUpdate.run())

    def on_close():
        process.interrupt(simpy.events.Event("Window closed"))
        top.destroy()
    top.protocol("WM_DELETE_WINDOW", on_close)



class tkinterGUI_main:

    def __init__(self, env, FAB, LOTS, event_simulation):
        self.main = None
        self.tkUpdate = None

        self.env = env
        self.FAB = FAB
        self.LOTS = LOTS
        self.event_simulation = event_simulation

    def create_gui(self):
        self.main = tk.Tk()
        self.main.title("Fab Simulation")
        self.main.config(bg="#000")

        width = 1400

        # ----------------------------------------------
        # (1) Frame: Skyworks Logo
        # ----------------------------------------------



        # ----------------------------------------------
        # (2) FigureCanvas: main figures
        # ----------------------------------------------
        fig_main = plt.Figure(figsize=(14, 4), dpi=72)

        fig_WIP = fig_main.add_subplot(131)
        fig_WIP.set_yticks([])

        fig_avg_queue_time = fig_main.add_subplot(132)
        fig_avg_queue_time.set_yticks([])

        fig_CTs = fig_main.add_subplot(133)

        plt.subplots_adjust(left=0.04, right=0.9, top=0.9, bottom=0.05)
        fig_main.tight_layout()

        figCanvas_main = FigureCanvasTkAgg(fig_main, master=self.main)
        figCanvas_main.get_tk_widget().config(height = 400)
        figCanvas_main.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)



        # ----------------------------------------------
        # (3) Canvas: time clock and control buttons
        # ----------------------------------------------
        canvas = tk.Canvas(self.main, width=width, height=50, bg = "white")
        canvas.pack(side=tk.TOP, fill=tk.BOTH, expand = True)

        btn_end_simluation = tk.Button(self.main, text = "End Simulation", command = lambda: self.event_simulation.succeed(), anchor = tk.W)
        btn_end_simluation.configure(width = 13, activebackground = "#33B5E5", relief = tk.FLAT)
        btn_end_simluation_window = canvas.create_window(1280, 15, anchor=tk.NW, window=btn_end_simluation)
        canvas.pack(side=tk.TOP, fill=tk.BOTH, expand = True)

        # ----------------------------------------------
        # (4) FigureCanvas: utilization figures
        # ----------------------------------------------
        fig_utilization, axs = plt.subplots(2, 2, figsize=(14, 2.4), dpi=72)

        axs[0, 0].set_yticks([])
        axs[0, 1].set_yticks([])
        axs[1, 0].set_yticks([])
        axs[1, 1].set_yticks([])

        plt.subplots_adjust(left=0.04, right=0.9, top=0.9, bottom=0.05)
        fig_utilization.tight_layout()

        figCanvas_utilization = FigureCanvasTkAgg(fig_utilization, master=self.main)
        figCanvas_utilization.get_tk_widget().config(height = 240)
        figCanvas_utilization.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        # Update (2), (3), and (4)
        self.tkUpdate = TkUpdate_Main(env=self.env, FAB=self.FAB, LOTS=self.LOTS, 
            canvas=canvas,
            figCanvas_main=figCanvas_main, dict_figsToPlot={"fig_WIP":fig_WIP, "fig_avg_queue_time":fig_avg_queue_time, "fig_CTs":fig_CTs},
            figCanvas_utilization=figCanvas_utilization, axs=axs
        )



        # ----------------------------------------------
        # (5) Bottom canvas: buttons
        # ----------------------------------------------
        canvas_button = tk.Canvas(self.main, width=width, height=40, bg = "white")

        btn = tk.Button(self.main, text = "PHOTO EqpType Details", command = lambda: tkinterGUI_popup(self.env, self.FAB, self.LOTS), anchor = tk.W)
        btn.configure(width = 20, activebackground = "#33B5E5", relief = tk.FLAT)
        btn_window = canvas_button.create_window(10, 10, anchor=tk.NW, window=btn)
        canvas_button.pack(side=tk.LEFT, fill=tk.BOTH, expand = True)


    def run(self):
        self.create_gui()
        self.env.process(self.tkUpdate.run())
        self.main.mainloop()