import tkinter as tk
from matplotlib import patches
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import simpy


class TkUpdate_UtilizationPopup:
    def __init__(self,
        env     =None, 
        LOTS    =[], 
        FAB     =None, 
        figCanvas_utilization=None,
        axs                  =None,
        canvas = None
        ):
        self.env  = env
        self.LOTS = LOTS
        self.FAB  = FAB


        # text = None

        self.figCanvas_utilization = figCanvas_utilization
        self.axs = axs

        self.canvas = canvas


        self.fixedTextObjs = []
        module = self.FAB.modules['PHOTO']
        i = -1
        for eqptype_name in module.eqptypes:
            i += 1
            dict_tool_to_utilizations = module.dict_eqptype_to_tools_to_utilizations[eqptype_name]

            x = i*160 + 30
            self.fixedTextObjs.append(self.canvas.create_text(x, 10, text=eqptype_name, font=("Arial", 11, 'bold'), anchor = tk.NW))

            text = ""
            for tool in dict_tool_to_utilizations.keys():
                text += "\n"+tool+": "
            self.fixedTextObjs.append(self.canvas.create_text(x, 15, text=text, font=("Arial", 11), anchor = tk.NW))


        for textObj in self.fixedTextObjs:
            self.canvas.itemconfig(textObj, fill='#000000')


        self.changeableTextObjs = []

        self.canvas.update()



    def run(self):
        while True:
            try:
                self.tick()
                yield self.env.timeout(10)
            except simpy.Interrupt:
                break



    def tick(self):

        # plot utilization
        self.plot_utilization_test()
        
        if self.canvas is not None and self.canvas.winfo_exists():
            for textObj in self.changeableTextObjs:
                if self.canvas.winfo_exists():
                    self.canvas.delete(textObj)
            self.changeableTextObjs = []

            time = int((self.env.now//10)*10)
            module = self.FAB.modules['PHOTO']
            i = -1
            
            for eqptype_name in module.eqptypes:
                i += 1
                dict_tool_to_utilizations = module.dict_eqptype_to_tools_to_utilizations[eqptype_name]

                x = i*160 + 115

                text = ""
                
                for tool in dict_tool_to_utilizations.keys():
                    text += "\n" + str(int(dict_tool_to_utilizations[tool][time] * 100)) + "%"
                self.changeableTextObjs.append(self.canvas.create_text(x, 15, text=text, font=("Arial", 11), anchor = tk.NW))


            for textObj in self.changeableTextObjs:
                self.canvas.itemconfig(textObj, fill='#000000')
            # eqptype_name = list(module.eqptypes.keys())[0]
            # dict_tool_to_utilizations = module.dict_eqptype_to_tools_to_utilizations[eqptype_name]

            
            # text = eqptype_name
            # time = int((self.env.now//10)*10)
            # for tool in dict_tool_to_utilizations.keys():
            #     text += "\n"+tool+": "+str(int(dict_tool_to_utilizations[tool][time] * 100)) + "%"
            

            # self.canvas.delete(self.textObj)
            # self.textObj = self.canvas.create_text(10, 10, text=text, font=("Arial", 11), anchor = tk.NW)
            # self.canvas.itemconfig(self.textObj, fill='#000000')
            # for 
            # time_text = self.canvas.create_text(, 
            #                             text="Time = "+str(round(env.now, 1))+" hours",
            #                             font=time_text_params['font'],
            #                             anchor = tk.NW)
            # canvas.itemconfig(time_text, fill='#1f77b4')
            # canvas.pack(side=tk.TOP, fill=tk.BOTH, expand = True)

            # update
            self.figCanvas_utilization.draw()
            self.canvas.update()



    def plot_utilization_test(self):
        i = -1
        module = self.FAB.modules['PHOTO']
        for eqptype_name in module.eqptypes:
            i += 1
            dict_utilizations = module.dict_eqptype_to_utilizations[eqptype_name]

            dict_utilizations_limited = {}
            for t in dict_utilizations.keys():
                if t > self.env.now:
                    break
                elif t < self.env.now - 111: 
                    continue
                else:
                    dict_utilizations_limited[str(int(t/10))] = [dict_utilizations[t], 1-dict_utilizations[t]]

            category_names = ['Processing', 'Reserved']
            df = pd.DataFrame(dict_utilizations_limited, index=category_names).T
            self.percentage_bar(int(i/2), int(i%2), axs=self.axs, df=df, figName=eqptype_name)


    def percentage_bar(self, *index, axs=None, df=None, figName=""):
        timeLabels = df.index.tolist()
        dict_fromDf = df.to_dict(orient = 'list')
        category_names = list(dict_fromDf.keys())
        data = np.array(list(dict_fromDf.values()))

        category_colors = ['#228B22', '#90EE90']
        
        # if self.env.now//10 <= 10:
        #     pass
        # else:
        #     axs[index].set_xlim(self.env.now//10 - 11, self.env.now//10)

        axs[index].clear()
        # axs[index].set_xticklabels(labels=timeLabels, rotation=90) # rotate x-axis labels
        axs[index].set_xticklabels(labels=timeLabels, fontsize=8)
        axs[index].set_ylim(0,1)
        axs[index].set_yticks([])
        axs[index].set_xlabel("Utilization of " + figName)

        starts = 0
        for i, (colname, color) in enumerate(zip(category_names, category_colors)):
            heights = data[i,:]
            axs[index].bar(timeLabels, heights, bottom=starts, width=0.8,label=colname, color=color,edgecolor ='white')
            starts += heights  # accumulate the heights for next category

            # percentage_text = data[i,: ]/ data.sum(axis =0) #文本标记的数据
            # r, g, b, _ = color  # 这里进行像素的分割
            # text_color = 'white' if r * g * b < 0.5 else 'k'  #根据颜色基调分配文本标记的颜色
            # for y, (x, c) in enumerate(zip(xcenters, percentage_text)):
            #     axs[index].text(y, x, f'{round(c*100,0)}%', ha='center', va='center',
            #             color=text_color, rotation = 90) #添加文本标记
        # axs[index].legend(ncol=len(category_names), bbox_to_anchor=(0, 1),
        #           loc='lower left', fontsize='large') #设置图例
