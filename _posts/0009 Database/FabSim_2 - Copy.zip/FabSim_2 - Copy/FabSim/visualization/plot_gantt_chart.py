import matplotlib.pyplot as plt
import numpy as np
from matplotlib import patches


def plot_gantt_chart(
        LOTS=[],
        dict_eqptype_to_tools_active={},
        dict_prd_to_qty_in_lot={},
        plot_until= 300):
    #TODO: set some limitation of the lots size
    cmap = plt.get_cmap('turbo')
    colors = [cmap(i) for i in np.linspace(0, 1, 14)]

    ys = {}
    y = 2

    for eqptype in dict_eqptype_to_tools_active:
        for tool in dict_eqptype_to_tools_active[eqptype]:
            ys[tool] = y
            y += 2


    fig, axs = plt.subplots(figsize=(18, 9))

    # ax.set_xticks(np.arange(0, 15, 1))
    axs.set_xlim(0, plot_until)
    axs.set_ylim(0, y+3)

    for l in range(len(LOTS)):
        lot = LOTS[l]
        color = colors[list(dict_prd_to_qty_in_lot.keys()).index(lot.prd)]
        for i in range(len(lot.progress)):
            # x_left_down, y_down
            xld, yd = lot.progress[i][-2], ys[lot.progress[i][0]]
            # x_right_down
            xrd = lot.progress[i][-1]

            axs.add_patch(
                patches.Rectangle(
                    (xld, yd), # location
                    xrd - xld,      # width
                    2,      # height
                    color=color
                )
            )

    plt.grid(axis='x')
    plt.show()
