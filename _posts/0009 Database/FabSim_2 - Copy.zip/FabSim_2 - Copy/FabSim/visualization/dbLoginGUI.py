import tkinter as tk
from ..utils.DataDownload import DataDownload



def dbLoginGUI(return_result, service_id="", database=""):
    window = tk.Tk()
    window.title("Database Login")
    window.geometry("290x140")

    # Create a label and entry for the username input
    username_label = tk.Label(window, text="Username:")
    username_label.pack()
    username_entry = tk.Entry(window)
    username_entry.pack()

    # Create a label and entry for the password input
    password_label = tk.Label(window, text="Password:")
    password_label.pack()
    password_entry = tk.Entry(window, show="*")
    password_entry.pack()

    
    def validate_credentials(return_result):
        username = username_entry.get()
        password = password_entry.get()

        # Check if the credentials are correct
        try:
            datadownload = DataDownload(service_id=service_id, database=database, user=username, password=password)
            return_result.append(datadownload)
            window.destroy()
        except:
            password_entry.delete(0, tk.END)
            error_label.config(text="Incorrect service_id, database, username or password")

    # Create a button to submit the creden
    submit_button = tk.Button(window, text="Enter", command=lambda: validate_credentials(return_result))
    submit_button.pack()

    # Create a label for error messages
    error_label = tk.Label(window, fg="red")
    error_label.pack()

    def on_close():
        # Raise an exception to interrupt the program
        window.destroy()
        raise Exception("Window was closed before credentials were entered.")

    # Set the protocol to handle the window close event
    window.protocol("WM_DELETE_WINDOW", on_close)

    # Run the window
    window.mainloop()