import tkinter as tk
from matplotlib import patches
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


class TkUpdate_Main:
    def __init__(self, # x1, y1, x2, y2,
        env     =None, 
        LOTS    =[], 
        FAB     =None, 
        canvas  =None,
        figCanvas_main =None,
        dict_figsToPlot={'fig_WIP':None, 'fig_avg_queue_time':None, 'fig_CTs':None},
        figCanvas_utilization=None,
        axs                  =None
        ):
        # Create a clock in a rectangular area
        self.env  = env
        self.LOTS = LOTS
        self.FAB  = FAB

        self.canvas    = canvas
        self.time_text = self.canvas.create_text(50, 17.5, 
                                text="Time = "+str(round(env.now, 1))+" hours",
                                font=('Areial', 15, 'bold'),
                                anchor = tk.NW)
        self.canvas.itemconfig(self.time_text, fill='#1f77b4')

        self.figCanvas_main  = figCanvas_main
        self.dict_figsToPlot = dict_figsToPlot

        self.figCanvas_utilization = figCanvas_utilization
        self.axs = axs

        # self.lotsStarted  = []
        # self.lotsFinished = []

        # self.x1 = x1
        # self.y1 = y1
        # self.x2 = x2
        # self.y2 = y2
        
        # self.box      = canvas.create_rectangle(self.x1, self.y1, self.x2, self.y2, fill="#fff")
        
        # self.seller_wait = canvas.create_text(self.x1 + 10, self.y1 + 40, text = "Avg. Seller Wait  = "+str(avg_wait(seller_waits)), anchor = tk.NW)
        # self.scan_wait = canvas.create_text(self.x1 + 10, self.y1 + 70, text = "Avg. Scanner Wait = "+str(avg_wait(scan_waits)), anchor = tk.NW)
        # self.canvas.update()



    def run(self):
        while True:
            yield self.env.timeout(10)
            self.tick()



    def tick(self):
        self.canvas.delete(self.time_text)
        # self.canvas.delete(self.seller_wait)
        # self.canvas.delete(self.scan_wait)

        self.time_text = self.canvas.create_text(50, 17.5, 
                                text="Time = "+str(round(self.env.now, 1))+" hours",
                                font=('Areial', 15, 'bold'),
                                anchor = tk.NW)
        self.canvas.itemconfig(self.time_text, fill='#1f77b4')
        # self.seller_wait = canvas.create_text(self.x1 + 10, self.y1 + 30, text = "Avg. Seller Wait  = "+str(avg_wait(seller_waits))+"m", anchor = tk.NW)
        # self.scan_wait = canvas.create_text(self.x1 + 10, self.y1 + 50, text = "Avg. Scanner Wait = "+str(avg_wait(scan_waits))+"m", anchor = tk.NW)
        
        # plot main
        if self.dict_figsToPlot['fig_WIP'] != None:   self.plot_WIP(self.dict_figsToPlot['fig_WIP'])
        if self.dict_figsToPlot['fig_avg_queue_time'] != None: self.plot_avg_queue_time(self.dict_figsToPlot['fig_avg_queue_time'])
        if self.dict_figsToPlot['fig_CTs'] != None:   self.plot_CTs(self.dict_figsToPlot['fig_CTs'])

        # plot utilization
        self.plot_utilization()
        
        # update
        self.figCanvas_main.draw()
        self.figCanvas_utilization.draw()
        self.canvas.update()



    def plot_WIP(self, graph):
        '''Plot WIP in process and in queue of each module
        '''

        # x_axis_length = len(self.LOTS)
        x_axis_length = 250
        graph.cla()
        graph.set_xlabel("Number of Lots in Process/ Queue")
        graph.set_xlim(0, x_axis_length)
        graph.set_ylim(0, 42)
        graph.set_yticks([])

        y = 1
        for module in self.FAB.modules.values():
            qty_in_lot_in_process = module.qty_in_lot_in_process
            qty_in_lot_in_queue   = module.qty_in_lot_in_queue

            graph.add_patch(patches.Rectangle((0, y), qty_in_lot_in_process, 2, color='green'))
            graph.add_patch(patches.Rectangle((qty_in_lot_in_process, y), qty_in_lot_in_queue, 2, color='red'))

            graph.text(x_axis_length*0.76, y+0.5, module.name, fontsize=12, color='black')
            y += 2.5



    def plot_avg_queue_time(self, graph):
        '''Plot average queuing time of each module
        ''' 

        x_axis_length = 12
        graph.cla()
        graph.set_xlabel("Avg queueing time (hours)")
        graph.set_xlim(0, x_axis_length)
        graph.set_ylim(0, 42)
        graph.set_yticks([])

        y = 1
        for module in self.FAB.modules.values():
            graph.add_patch(patches.Rectangle((0, y), module.avg_queue_time, 2, color='#1f77b4'))
            graph.text(x_axis_length*0.76, y+0.5, module.name, fontsize=12, color='black')
            y += 2.5



    def plot_CTs(self, graph):
        '''Plot a histogram of cycle times of lots
        '''

        graph.cla()
        graph.set_xlabel("Cycle time of lots (hours)")

        CTs = [lot.cycle_time for lot in self.LOTS if lot.cycle_time != -1]
        graph.hist(CTs, bins=20, color='#ff7f0e')


    
    def plot_utilization(self):
        '''Plot utilization of the modules selected
        '''
        i = -1
        for mName in ['PHOTO', 'METALS', 'PROBE', 'CLEAN']:
            i += 1
            module = self.FAB.modules[mName]
            # {time: utilization}
            dict_utilizations = module.dict_utilizations

            # {time: [utilization, 1-utilization]}
            dict_utilizations_limited = {}
            for t in dict_utilizations.keys():
                if t > self.env.now:
                    break
                elif t < self.env.now - 111: 
                    continue
                else:
                    dict_utilizations_limited[str(int(t/10))] = [dict_utilizations[t], 1-dict_utilizations[t]]

            category_names = ['Processing', 'Reserved']
            df = pd.DataFrame(dict_utilizations_limited, index=category_names).T
            self.percentage_bar(int(i/2), int(i%2), axs=self.axs, df=df, figName=mName)


    def percentage_bar(self, *index, axs=None, df=None, figName=""):
        timeLabels = df.index.tolist()
        dict_fromDf = df.to_dict(orient = 'list')
        category_names = list(dict_fromDf.keys())
        data = np.array(list(dict_fromDf.values()))

        category_colors = ['#228B22', '#90EE90']
        
        # if self.env.now//10 <= 10:
        #     pass
        # else:
        #     axs[index].set_xlim(self.env.now//10 - 11, self.env.now//10)

        axs[index].clear()
        # axs[index].set_xticklabels(labels=timeLabels, rotation=90) # rotate x-axis labels
        axs[index].set_xticklabels(labels=timeLabels, fontsize=8)
        axs[index].set_ylim(0,1)
        axs[index].set_yticks([])
        axs[index].set_xlabel("Utilization of " + figName)

        starts = 0
        for i, (colname, color) in enumerate(zip(category_names, category_colors)):
            heights = data[i,:]
            axs[index].bar(timeLabels, heights, bottom=starts, width=0.8,label=colname, color=color,edgecolor ='white')
            starts += heights  # accumulate the heights for next category

            # percentage_text = data[i,: ]/ data.sum(axis =0) #文本标记的数据
            # r, g, b, _ = color  # 这里进行像素的分割
            # text_color = 'white' if r * g * b < 0.5 else 'k'  #根据颜色基调分配文本标记的颜色
            # for y, (x, c) in enumerate(zip(xcenters, percentage_text)):
            #     axs[index].text(y, x, f'{round(c*100,0)}%', ha='center', va='center',
            #             color=text_color, rotation = 90) #添加文本标记
        # axs[index].legend(ncol=len(category_names), bbox_to_anchor=(0, 1),
        #           loc='lower left', fontsize='large') #设置图例
