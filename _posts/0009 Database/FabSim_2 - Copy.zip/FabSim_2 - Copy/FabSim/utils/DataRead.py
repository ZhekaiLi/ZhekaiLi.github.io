import logging
import pandas as pd
import re

class DataRead:
    """
    get_...():      means directly get the data from csv tables
    get_..._from(): means get the data from other dictionaries (and can also partly from csv tables)
    """

    def get_eqptype_to_module(table_dir='data/FPSTables/EQP_TOOL_MSO_GROUPS.csv'):
        # {eqptype: module}
        df = pd.read_csv(table_dir)
        dict_eqptype_to_module = {}

        for index, row in df.iterrows():
            eqptype = row['tool_mso_group']
            module = row['tool_mso_module']
            dict_eqptype_to_module[eqptype] = module

        return dict_eqptype_to_module



    def get_eqptype_to_tools_from(dict_route_to_eqptypes=[], dict_route_to_tool_lists=[]):
        # {eqp_type: [tool]}
        dict_eqptype_to_tools = {}
        for rt in dict_route_to_eqptypes:
            for i in range(len(dict_route_to_eqptypes[rt])):
                eqptype = dict_route_to_eqptypes[rt][i]
                tools = dict_route_to_tool_lists[rt][i]

                if eqptype not in dict_eqptype_to_tools :
                    dict_eqptype_to_tools [eqptype] = []
                for tool in tools:
                    if tool not in dict_eqptype_to_tools [eqptype]:
                        dict_eqptype_to_tools [eqptype].append(tool)
        return dict_eqptype_to_tools 



    def get_eqptype_to_tools_mapping(table_dir='data/FPSTables/EQP_TOOLS_PLUS.csv'):
        dict_tool_to_eqptype = {}
        dict_eqptype_to_tools = {}

        df = pd.read_csv(table_dir)
        for index, row in df.iterrows():
            dict_tool_to_eqptype[row['tool']] = row['eqp_type']
            if row['eqp_type'] not in dict_eqptype_to_tools:
                dict_eqptype_to_tools[row['eqp_type']] = set()
            dict_eqptype_to_tools[row['eqp_type']].add(row['tool'])

        return dict_eqptype_to_tools, dict_tool_to_eqptype
    


    def get_eqptype_to_tool_to_chamber_MANY(table_dir='data/FPSTables/EQP_ENTITIES.csv'):
        dict_eqptype_to_tool_to_chamber_names = {}
        dict_eqptype_to_tool_to_chamber_types = {}
        dict_eqptype_to_tool_to_chamber_type_to_count = {}

        df = pd.read_csv(table_dir)
        for index, row in df.iterrows():
            eqptype = row['eqp_type']
            tool = row['tool']
            ch_name = row['entity']
            ch_type = row['ch_type']

            if eqptype not in dict_eqptype_to_tool_to_chamber_names:
                dict_eqptype_to_tool_to_chamber_names[eqptype] = {}
                dict_eqptype_to_tool_to_chamber_types[eqptype] = {}
            if tool not in dict_eqptype_to_tool_to_chamber_names[eqptype]:
                dict_eqptype_to_tool_to_chamber_names[eqptype][tool] = []
                dict_eqptype_to_tool_to_chamber_types[eqptype][tool] = []
            if tool != ch_name:
                dict_eqptype_to_tool_to_chamber_names[eqptype][tool].append(ch_name)
                dict_eqptype_to_tool_to_chamber_types[eqptype][tool].append(ch_type)

        for eqptype in dict_eqptype_to_tool_to_chamber_types:
            for tool in dict_eqptype_to_tool_to_chamber_types[eqptype]:
                if len(dict_eqptype_to_tool_to_chamber_types[eqptype][tool]) > 0:
                    ch_types = dict_eqptype_to_tool_to_chamber_types[eqptype][tool]
                    dict_chamber_type_to_count = {}
                    for ch_type in ch_types:
                        dict_chamber_type_to_count[ch_type] = dict_chamber_type_to_count.get(ch_type, 0) + 1

                    if eqptype not in dict_eqptype_to_tool_to_chamber_type_to_count:
                        dict_eqptype_to_tool_to_chamber_type_to_count[eqptype] = {}

                    dict_eqptype_to_tool_to_chamber_type_to_count[eqptype][tool] = dict_chamber_type_to_count
        return dict_eqptype_to_tool_to_chamber_names, dict_eqptype_to_tool_to_chamber_types, dict_eqptype_to_tool_to_chamber_type_to_count



    def get_init_prd_to_step_to_wafer_nums(table_dir='data/FPSTables/WIP_LOTS_REALTIME.csv', dict_prd_to_valid_steps={}):
        '''Get the lots that are already in the fab

        input:
            table_dir: the directory of the table
            dict_prd_to_valid_steps: {prd: [valid_step]}

        return:
            dict_init_prd_to_step_to_wafer_nums: {prd: {step: [wafer_num_of_lot_1, wafer_num_of_lot_2, ...]}}
        '''
        dict_init_prd_to_step_to_wafer_nums = {}

        df = pd.read_csv(table_dir)
        for index, row in df.iterrows():
            prd = row['prd']
            step = row['step']
            # Check if the prd and step is valid to be initialized
            if prd not in dict_prd_to_valid_steps.keys():
                logging.warning(f"Cannot initialize product {prd} because it's not in dict_prd_to_valid_steps")
                continue
            if step not in dict_prd_to_valid_steps[prd]:
                logging.warning(f"Cannot initialize step {step} of product {prd} because it's not in dict_prd_to_valid_steps")
                continue

            if prd not in dict_init_prd_to_step_to_wafer_nums.keys():
                dict_init_prd_to_step_to_wafer_nums[prd] = {}
            if step not in dict_init_prd_to_step_to_wafer_nums[prd].keys():
                dict_init_prd_to_step_to_wafer_nums[prd][step] = []
            dict_init_prd_to_step_to_wafer_nums[prd][step].append(row['qty'])
        
        return dict_init_prd_to_step_to_wafer_nums



    def get_prd_to_MANY_from(table_dir='data/FPSTables/RTG_PRD_STEP_EQPTYPES.csv', 
                             dict_eqptype_to_tools=[], dict_step_to_tools=[],
                             dict_eqptype_to_tool_to_chamber_type_to_count=[]):
        # {prd: route}
        dict_prd_to_route = {}

        # {prd: [step]}
        # {prd: [valid_step]}
        dict_prd_to_steps = {}
        dict_prd_to_valid_steps = {}

        # {prd: {step: smp_pct}}
        # {prd: {step: [eqptype]}
        # {prd: {step: [use_pct]}
        dict_prd_to_step_to_smp_pct = {}
        dict_prd_to_step_to_eqptypes = {}

        # {prd: {step: {eqptype: mpu}}}
        # {prd: {step: {eqptype: [tools]}}}
        # {prd: {step: {eqptype: use_pct}}}
        # {prd: {step: {eqptype: {chamber_type: count}}}}
        dict_prd_to_step_to_eqptype_to_mpu = {}
        dict_prd_to_step_to_eqptype_to_tools = {}
        dict_prd_to_step_to_eqptype_to_use_pct = {}
        dict_prd_to_step_to_eqptype_to_chamber_requirement = {}

        pre_step = None
        df = pd.read_csv(table_dir)

        for index, row in df.iterrows():
            prd  = row['prd']
            step = row['step']
            eqptype = row['eqp_type']
            ch_type_cnt = row['which_ch_type_cnt']

            if prd not in dict_prd_to_steps:
                dict_prd_to_route[prd] = row['route']

                dict_prd_to_steps[prd] = []
                dict_prd_to_valid_steps[prd] = []

                dict_prd_to_step_to_smp_pct[prd] = {}
                dict_prd_to_step_to_eqptypes[prd] = {}

                dict_prd_to_step_to_eqptype_to_use_pct[prd] = {}
                dict_prd_to_step_to_eqptype_to_mpu[prd] = {}
                dict_prd_to_step_to_eqptype_to_tools[prd] = {}
                dict_prd_to_step_to_eqptype_to_chamber_requirement[prd] = {}
            
            if step not in dict_prd_to_step_to_eqptype_to_chamber_requirement[prd]:
                dict_prd_to_step_to_eqptype_to_chamber_requirement[prd][step] = {}

            if ch_type_cnt != 'NA' and not pd.isna(ch_type_cnt):
                chamber_requirement = {}
                splits = ch_type_cnt.split('+')

                for split in splits:
                    chamber_requirement[split[1:]] = int(split[0])
                dict_prd_to_step_to_eqptype_to_chamber_requirement[prd][step][eqptype] = chamber_requirement
            else:
                dict_prd_to_step_to_eqptype_to_chamber_requirement[prd][step][eqptype] = 'NA'

            # for the same prd-step, different eqptype share the same sampling rate
            dict_prd_to_step_to_smp_pct[prd][step] = row['est_smp_pct'] / 100


            if pre_step != step:
                dict_prd_to_steps[prd].append(step)
                dict_prd_to_step_to_eqptypes[prd][step] = [eqptype]
                dict_prd_to_step_to_eqptype_to_use_pct[prd][step] = {eqptype: row['est_use_pct']}
                dict_prd_to_step_to_eqptype_to_mpu[prd][step] = {eqptype: row['mpu']}
                dict_prd_to_step_to_eqptype_to_tools[prd][step] = {}
            else:
                dict_prd_to_step_to_eqptypes[prd][step].append(eqptype)
                dict_prd_to_step_to_eqptype_to_use_pct[prd][step][eqptype] = row['est_use_pct']
                dict_prd_to_step_to_eqptype_to_mpu[prd][step][eqptype] = row['mpu']


            is_valid_step = True
            mask1 = (row['process'] == 'SM') or (row['process'] == 'ML') or (re.search("SAP LOT ST", row['process']))
            mask2 = (eqptype == 'NA') or (re.search("DUMMY", eqptype))
            mask3 = (eqptype == 'N_SAPST') or (eqptype == 'N_TOFAB')
            if mask1 or mask2 or mask3:
                is_valid_step = False
            else:
                if eqptype not in dict_prd_to_step_to_eqptype_to_tools[prd][step]:
                    tools = []
                    set1 = dict_eqptype_to_tools[eqptype]
                    try:
                        set2 = dict_step_to_tools[step]
                        if set1.intersection(set2) == set():
                            # logging.warning(f"Warning: eqp_type {row['eqp_type']} at step {step} has no specific tools")
                            raise KeyError
                        else:
                            tools = list(set1.intersection(set2))
                    except KeyError:
                        tools = list(set1)

                    valid_tools = []
                    if dict_prd_to_step_to_eqptype_to_chamber_requirement[prd][step][eqptype] == 'NA':
                        for tool in tools:
                            if eqptype not in dict_eqptype_to_tool_to_chamber_type_to_count.keys():
                                valid_tools.append(tool)
                            else:
                                if tool not in dict_eqptype_to_tool_to_chamber_type_to_count[eqptype].keys():
                                    valid_tools.append(tool)
                    else: # has chambers
                        if eqptype not in dict_eqptype_to_tool_to_chamber_type_to_count.keys():
                            is_valid_step = False
                            # print(f"Error: eqp_type {row['eqp_type']} at step {step} has no chamber")
                        else:
                            for tool in tools:
                                if tool not in dict_eqptype_to_tool_to_chamber_type_to_count[eqptype]:
                                    continue
                                try:
                                    for ch_type in dict_prd_to_step_to_eqptype_to_chamber_requirement[prd][step][eqptype]:
                                        cnt1 = dict_prd_to_step_to_eqptype_to_chamber_requirement[prd][step][eqptype][ch_type]
                                        if ch_type not in dict_eqptype_to_tool_to_chamber_type_to_count[eqptype][tool]:
                                            raise ValueError
                                        cnt2 = dict_eqptype_to_tool_to_chamber_type_to_count[eqptype][tool][ch_type]
                                        if cnt1 > cnt2:
                                            raise ValueError
                                    valid_tools.append(tool)
                                except ValueError:
                                    continue

                    if len(valid_tools) == 0:
                        # logging.error(f"Error: eqp_type {row['eqp_type']} at step {step} has no tool to run")
                        is_valid_step = False
                    else:
                        dict_prd_to_step_to_eqptype_to_tools[prd][step][eqptype] = valid_tools

            #TODO: 这里还需要继续考虑特殊情况，比如如果set是空的，那么这一步就不是valid step
            if is_valid_step:
                if step != pre_step:
                    dict_prd_to_valid_steps[prd].append(step)
            pre_step = step
        # return
        return dict_prd_to_route, \
            dict_prd_to_steps, \
            dict_prd_to_valid_steps, \
            dict_prd_to_step_to_smp_pct, \
            dict_prd_to_step_to_eqptypes, \
            dict_prd_to_step_to_eqptype_to_use_pct, \
            dict_prd_to_step_to_eqptype_to_mpu, \
            dict_prd_to_step_to_eqptype_to_tools, \
            dict_prd_to_step_to_eqptype_to_chamber_requirement



    def get_prd_to_PLAN(table_dir='data/Standard Production Plan.csv', valid_prds=[]):
        # {product: quantity in lot}
        dict_prd_to_PLAN = {}
        df = pd.read_csv(table_dir)
        for index, row in df.iterrows():
            prd = row['prd']

            if prd not in valid_prds:
                logging.warning(f"Cannot create product {prd} because it's not in valid_prds")
                continue

            dict_prd_to_PLAN[prd] = {
                'qty_in_lot': row['qty'],
                'wafer_num': row['wafer_num'],
                'priority': row['priority'],
                'due_time_since_release_in_hour': row['due_time_since_release_in_hour']
            }

        return dict_prd_to_PLAN



    def get_prd_to_qty_in_wafer(table_dir='data/Copy of Mix Plan MRP 4-01-23.xlsx', valid_prds=[]):
        # {product: quantity in wafer}
        #TODO: this function should be customized by the user because the table is not uniform
        dict_prd_to_qty_in_wafer = {}
        df = pd.read_excel(table_dir, sheet_name='Mix Plan Current')
        rowNum = 2 # the first row is the header
        for index, row in df.iterrows():
            if rowNum > 135: # rows below is not useful
                break

            prd = row['Material ']            
            if prd not in valid_prds:
                logging.warning(f"Cannot create product {prd} because it's not in valid_prds")
                continue

            qty = row[f'Q3\'23']
            if qty > 0:
                dict_prd_to_qty_in_wafer[prd] = qty
            rowNum += 1

        return dict_prd_to_qty_in_wafer



    def get_prd_to_routes_from(table_dir='data/FPSTables/CTM_WEEK_HIST.csv', dict_route_to_eqptypes=[], dict_prd_to_qty_in_wafer=[]):
        # {product: [route]}
        df = pd.read_csv(table_dir)
        dict_prd_to_routes = {}

        for index, row in df.iterrows():
            prd = row['prd']
            route = row['route']
            if route in dict_route_to_eqptypes.keys():
                if prd not in dict_prd_to_routes:
                    dict_prd_to_routes[prd] = [route]
                else:
                    dict_prd_to_routes[prd].append(route)

        print("The following products do not exist in table {}".format(table_dir))
        for prd in dict_prd_to_qty_in_wafer:
            if prd not in dict_prd_to_routes.keys():
                print(prd, dict_prd_to_qty_in_wafer[prd])

        return dict_prd_to_routes



    def get_prd_to_route_from(dict_prd_to_qty_in_wafer=[], dict_prd_to_routes=[], dict_route_to_eqptypes=[]):
        # {product: route}
        dict_prd_to_route = {} # (1-to-1)

        #TODO: 不知道这里是不是应该用100为标准，是不是所有 products 的步骤数量都大于100？
        # Check if there is a route with more than 100 steps
        # If there are more than one route with more than 100 steps, print the prd and the routes
        for prd in dict_prd_to_qty_in_wafer:
            if prd in dict_prd_to_routes.keys():
                route_list = [route for route in dict_prd_to_routes[prd] if len(dict_route_to_eqptypes[route]) > 100]
                if len(route_list) == 0:
                    print(prd)
                    print("Error! No route with more than 100 steps")
                elif len(route_list) == 1:
                    dict_prd_to_route[prd] = route_list[0]
                else:
                    print(prd)
                    print(route_list)

        # Manually assign the route to the prd (according to the FPS Dashboard)
        route = 'N_6HBT8-M3-MC+N_6CUTE-M3-NOSTREET+N_6P07_TWV-ETC+N_6FPOUTS-NS>N_PC'
        prd = 'ZT011-J1NS'
        print("Manually assign the route {} to the product {}".format(route, prd))
        dict_prd_to_route[prd] = route

        return dict_prd_to_route



    def get_prd_to_step_to_tool_to_MPU(table_dir='data/FPSTables/THP_TOOL_SUMMARY.csv'):
        # {prd: {step: {tool: MPU}}}
        dict_prd_to_step_to_tool_to_MPU = {}

        df = pd.read_csv(table_dir)
        for index, row in df.iterrows():
            if not pd.isna(row['mpu']) and row['mpu'] != 'NA':
                prd = row['prd']
                step = row['step']
                tool = row['tool']
                if prd not in dict_prd_to_step_to_tool_to_MPU:
                    dict_prd_to_step_to_tool_to_MPU[prd] = {}
                if step not in dict_prd_to_step_to_tool_to_MPU[prd]:
                    dict_prd_to_step_to_tool_to_MPU[prd][step] = {}
                dict_prd_to_step_to_tool_to_MPU[prd][step][tool] = row['mpu']

        return dict_prd_to_step_to_tool_to_MPU
            


    
    def get_recipes_tools_mapping(table_dir='data/FPSTables/RTG_PROCESS_RCP_TOOL_BASE.csv'):
        # {recipe: [tool]}
        df = pd.read_csv(table_dir)
        dict_recipe_to_tools = {}
        dict_tool_to_recipes = {}
        for index, row in df.iterrows():
            if row['est_machine_recipe'] not in dict_recipe_to_tools:
                dict_recipe_to_tools[row['est_machine_recipe']] = []
            dict_recipe_to_tools[row['est_machine_recipe']].append(row['tool'])

            if row['tool'] not in dict_tool_to_recipes:
                dict_tool_to_recipes[row['tool']] = []
            dict_tool_to_recipes[row['tool']].append(row['est_machine_recipe'])

        return dict_recipe_to_tools, dict_tool_to_recipes



    def get_recipe_to_eqptypes_to_MPU(table_dir='data/FPSTables/RTG_PROCESS_RCP_EQPTYPES.csv'):
        # {recipe: {eqp_type: MPU}}
        dict_recipe_to_eqptypes_to_MPU = {}
        df = pd.read_csv(table_dir)

        for index, row in df.iterrows():
            if row['recipe'] not in dict_recipe_to_eqptypes_to_MPU:
                dict_recipe_to_eqptypes_to_MPU[row['recipe']] = {}
            dict_recipe_to_eqptypes_to_MPU[row['recipe']][row['eqp_type']] = row['mpu']

        return dict_recipe_to_eqptypes_to_MPU



    def get_route_to_MANY_from(table_dir='data/FPSTables/RTG_ROUTE_STEPS_PLUS.csv', dict_recipe_to_tools=[], dict_tool_to_eqptype=[]):
        '''
        {route: [valid_seq_num]}
        {route: [recipe]}
        {route: [eqp_type]}
        {route: [sampling_rate]}
        {route: [[tool]]}
        '''
        dict_route_to_valid_seq_nums = {}
        dict_route_to_recipes = {}
        dict_route_to_eqptypes = {}
        dict_route_to_sampling_rates = {}

        dict_route_to_tool_lists = {}

        df = pd.read_csv(table_dir)
        for index, row in df.iterrows():
            if row['route'] not in dict_route_to_recipes:
                dict_route_to_recipes[row['route']] = []
                dict_route_to_eqptypes[row['route']] = []
                dict_route_to_sampling_rates[row['route']] = []
                dict_route_to_valid_seq_nums[row['route']] = []

                dict_route_to_tool_lists[row['route']] = []

            dict_route_to_recipes[row['route']].append(row['recipe'])
            dict_route_to_eqptypes[row['route']].append(row['eqp_type'])
            dict_route_to_sampling_rates[row['route']].append(row['sampling_rate']/100)

            dict_route_to_tool_lists[row['route']].append([])


            # only record the valid row (with valid recipe and eqp_type that could be found in the other tables)
            ifValid = True
            # eliminate NULL (nan), return True if there is any NULL
            mask1 = (row['eqp_type'] != row['eqp_type']) or (row['recipe'] != row['recipe']) or (row['process'] != row['process'])
            
            if mask1:
                ifValid = False
            else:
                # eliminate recipe that is not in dict_recipe_to_tools, return True if not in
                mask2 = (row['recipe'] not in dict_recipe_to_tools.keys()) or (row['recipe'] == 'SM')
                # from Sam
                mask3 = (row['process'] == 'SM') or (row['process'] == 'ML') or (re.search("SAP LOT ST", row['process']))
                mask4 = (row['eqp_type'] == 'NA') or (re.search("DUMMY", row['eqp_type']))
                # V3.2 Update
                mask5 = (row['eqp_type'] == 'N_SAPST') or (row['eqp_type'] == 'N_TOFAB')
                if mask2 or mask3 or mask4 or mask5:
                    ifValid = False
                else:
                    # only add the tool that belongs to the eqp_type of that recipe
                    for tool in dict_recipe_to_tools[row['recipe']]:
                        if dict_tool_to_eqptype[tool] == row['eqp_type']:
                            dict_route_to_tool_lists[row['route']][-1].append(tool)
                    # if no tool is added, then it is not valid
                    if len(dict_route_to_tool_lists[row['route']][-1]) == 0:
                        print("Route {}, recipe {}, eqp_type {}, seq_num {} has no valid tool to run".format(row['route'], row['recipe'], row['eqp_type'], row['seq_num']))
                        ifValid = False

            if ifValid:
                # minus 1 because the seq_num starts from 1, but the index of the list starts from 0
                dict_route_to_valid_seq_nums[row['route']].append(int(row['seq_num']-1))

        return dict_route_to_valid_seq_nums, dict_route_to_recipes, dict_route_to_eqptypes, dict_route_to_sampling_rates, dict_route_to_tool_lists
    


    def get_route_to_qty_in_wafer_from(dict_prd_to_route=[], dict_prd_to_qty_in_wafer=[]):
        # {route: quantity}
        dict_route_to_qty_in_wafer = {}

        for prd in dict_prd_to_route:
            route = dict_prd_to_route[prd]
            qty = dict_prd_to_qty_in_wafer[prd]
            if route not in dict_route_to_qty_in_wafer:
                dict_route_to_qty_in_wafer[route] = qty
            else:
                dict_route_to_qty_in_wafer[route] += qty

        return dict_route_to_qty_in_wafer


    
    def get_route_to_seq_nums_init_from(table_dir='data/FPSTables/WIP_LOTS_REALTIME.csv', dict_route_to_recipes=[]):
        dict_route_to_lot_seq_nums_init = {}

        df = pd.read_csv(table_dir)
        for index, row in df.iterrows():
            route = row['route']
            if route in dict_route_to_recipes.keys():
                if route not in dict_route_to_lot_seq_nums_init:
                    dict_route_to_lot_seq_nums_init[route] = []
                dict_route_to_lot_seq_nums_init[route].append(int(row['seq_num']-1))
            else:
                print("Cannot find {} in dict_route_to_recipes".format(route))
        
        return dict_route_to_lot_seq_nums_init


    
    def get_step_to_tools(table_dir='data/FPSTables/RTG_TOOL_ASSIGNMENTS_LOT.csv'):
        dict_step_to_tools = {}

        df = pd.read_csv(table_dir)

        for index, row in df.iterrows():
            step = row['step']
            tool = row['tool']
            if step not in dict_step_to_tools:
                dict_step_to_tools[step] = set()
            dict_step_to_tools[step].add(tool)

        return dict_step_to_tools


    def get_tool_to_eqptype(table_dir='data/FPSTables/EQP_TOOLS_PLUS.csv'):
        # {tool: eqp_type}
        df = pd.read_csv(table_dir)
        dict_tool_to_eqptype = {}

        for index, row in df.iterrows():
            dict_tool_to_eqptype[row['tool']] = row['eqp_type']
        return dict_tool_to_eqptype
    


    def get_tool_to_recipes_to_MPU_from(
            table_dir='data/FPSTables/THP_TOOL_SUMMARY.csv',
            dict_route_to_valid_seq_nums=[],
            dict_route_to_recipes=[], 
            dict_route_to_eqptypes=[],
            dict_route_to_tool_lists=[], 
            dict_recipe_to_eqptypes_to_MPU=[]):

        # {tool: {recipe: MPU}}
        dict_tool_to_recipes_to_MPU = {}

        for rt in dict_route_to_valid_seq_nums:
            for seq_num in dict_route_to_valid_seq_nums[rt]:
                recp = dict_route_to_recipes[rt][seq_num]
                tools = dict_route_to_tool_lists[rt][seq_num]
                eqptype = dict_route_to_eqptypes[rt][seq_num]

                for t in tools:
                    if t not in dict_tool_to_recipes_to_MPU:   
                        dict_tool_to_recipes_to_MPU[t] = {}
                    dict_tool_to_recipes_to_MPU[t][recp] = dict_recipe_to_eqptypes_to_MPU[recp][eqptype]

        # update dict_tool_to_recipesMPU with more precise data
        # in the previous one, 所有可以运行某个 recipe 且属于同一个 eqp_type 的 tool 都会被赋予同一个 MPU
        # 但是现在，虽然 THP_TOOL_SUMMARY 只包含少量 recipe - tool to mpu 的数据，但是仍然可以用于更新 dict_tool_to_recipesMPU
        df = pd.read_csv(table_dir)
        for index, row in df.iterrows():
            try:
                dict_tool_to_recipes_to_MPU[row['tool']][row['est_machine_recipe']] = row['mpu_auto']
            except:
                print("Cannot find the pair {} - {} from {} in {}".format(row['tool'], row['est_machine_recipe'], 'THP_TOOL_SUMMARY.csv', 'dict_tool_to_recipes_to_MPU'))

        return dict_tool_to_recipes_to_MPU
