

def getPrdPlan(dict_prd_to_qty_in_wafer={}, size_scaler=260):
    '''filter out the invalid prds
    
    args:
        dict_prd_to_qty_in_wafer: {prd: qty}, SOURCE DATA, from the mix_plan_data that shows quarterly production plan of each product
        size_scaler:              float, denominator of the size of each lot
    '''

    dict_valid_prd_to_qty_in_lot = {}

    for prd in dict_prd_to_qty_in_wafer.keys():
        if dict_prd_to_qty_in_wafer[prd] // size_scaler > 0:
            dict_valid_prd_to_qty_in_lot[prd] = dict_prd_to_qty_in_wafer[prd] // size_scaler

    return dict_valid_prd_to_qty_in_lot
    