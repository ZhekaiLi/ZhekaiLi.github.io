import pandas as pd
import os
import csv

class DataWrite:
    def __init__(self, LOTS=[], FAB=None, results_dir=""):
        self.LOTS = LOTS
        self.FAB = FAB
        self.results_dir = f"{results_dir}/data_results"
        os.makedirs(self.results_dir, exist_ok=True)


    #TODO: output the pictures if possible
    def write_lot_info(self):
        '''Write lot's attributes (id, route, priority, start_time, due_time, cycle_time) to csv file
        '''
        ids = [lot.id for lot in self.LOTS]
        wafer_nums = [lot.wafer_num for lot in self.LOTS]
        prds = [lot.prd for lot in self.LOTS]
        routes = [lot.route for lot in self.LOTS]
        priorities = [lot.priority for lot in self.LOTS]
        sts = [lot.start_time_in_hour for lot in self.LOTS]
        dts = [lot.due_time_in_hour for lot in self.LOTS]
        cts = [lot.cycle_time for lot in self.LOTS]
        df = pd.DataFrame({
            'id': ids,
            'wafer_num': wafer_nums,
            'prd': prds,
            'route': routes,
            'priority': priorities,
            'start_time_in_hour': sts,
            'due_time_in_hour': dts,
            'cycle_time': cts
        })
        df.to_csv(f"{self.results_dir}/lot_info.csv", index=False)

        os.makedirs(f"{self.results_dir}/lot_progress_detailed", exist_ok=True)
        for i in range(len(self.LOTS)):
            lot = self.LOTS[i]
            
            df = pd.DataFrame({
                'tool': [progress[0] for progress in lot.progress],
                'step_num': [progress[1] for progress in lot.progress],
                'step': [progress[2] for progress in lot.progress],
                'time_start': [progress[3] for progress in lot.progress],
                'time_end': [progress[4] for progress in lot.progress]
            })
            df.to_csv(f"{self.results_dir}/lot_progress_detailed/lot_{i}.csv", index=False)
            # with open(f"{self.results_dir}/lot_{i}.csv", 'w') as file:
            #     writer = csv.writer(file)
            #     writer.writerow(lot.progress)
            
    

    
    def write_lot_progress(self):
        #TODO: 这个函数会和新的逻辑有关，需要在新逻辑被确定后再继续完善
        pass


    
    def write_utilization(self):
        os.makedirs(f"{self.results_dir}/untilization", exist_ok=True)
        for module in self.FAB.modules.values():
            dict_utils = {
                'time': module.dict_utilizations.keys(),
                'avg_util_module': module.dict_utilizations.values()
            }
            for eqptype_name in module.dict_eqptype_to_utilizations:
                dict_utils[f'avg_util_{eqptype_name}'] = module.dict_eqptype_to_utilizations[eqptype_name].values()
                for tool_name in module.dict_eqptype_to_tools_to_utilizations[eqptype_name]:
                    dict_utils[f'util_{tool_name}'] = module.dict_eqptype_to_tools_to_utilizations[eqptype_name][tool_name].values()

            df = pd.DataFrame(dict_utils)
            df.to_csv(f"{self.results_dir}/untilization/utilization_{module.name}.csv", index=False)



    def write_wip_and_queue_hist(self):
        '''Write wip and queue history of each module to csv file
        '''
        os.makedirs(f"{self.results_dir}/wip_and_queue_hist", exist_ok=True)
        for module in self.FAB.modules.values():
            df = pd.DataFrame({
                'time': module.time_HIST,
                'qty_in_lot_in_process': module.qty_in_lot_in_process_HIST,
                'qty_in_lot_in_queue': module.qty_in_lot_in_queue_HIST
            })
            df.to_csv(f"{self.results_dir}/wip_and_queue_hist/wip_and_queue_hist_{module.name}.csv", index=False)


