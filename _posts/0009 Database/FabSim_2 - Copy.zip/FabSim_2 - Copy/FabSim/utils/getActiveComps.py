import copy

def getActiveComps(prds_active, dict_prd_to_valid_steps, dict_prd_to_step_to_eqptype_to_tools):
    """Get the active components needed to be modeled in the fab.
    """
    dict_eqptype_to_tools_active = {}
    for prd in prds_active:
        for step in dict_prd_to_valid_steps[prd]:
            eqptypes = list(dict_prd_to_step_to_eqptype_to_tools[prd][step].keys())

            if len(eqptypes) == 1:
                eqptype = eqptypes[0]
                tools = copy.deepcopy(dict_prd_to_step_to_eqptype_to_tools[prd][step][eqptype])
                if eqptype not in dict_eqptype_to_tools_active:
                    dict_eqptype_to_tools_active[eqptype] = []
                for tool in tools:
                    if tool not in dict_eqptype_to_tools_active[eqptype]:
                        dict_eqptype_to_tools_active[eqptype].append(tool)
            else:
                for eqptype in eqptypes:
                    tools = copy.deepcopy(dict_prd_to_step_to_eqptype_to_tools[prd][step][eqptype])
                    if eqptype not in dict_eqptype_to_tools_active:
                        dict_eqptype_to_tools_active[eqptype] = []
                    # try:
                    #     tools = copy.deepcopy(dict_prd_to_step_to_eqptype_to_tools[prd][step][eqptype])
                    # except:
                    #     continue
                    # #     print(dict_prd_to_step_to_eqptype_to_tools[prd][step])
                    # #     print('-------------------')
                    # #     print(dict_prd_to_step_to_eqptypes[prd][step])
                    # #     exit()
                    # # if eqptype not in dict_eqptype_to_tools_active:
                    # #    dict_eqptype_to_tools_active[eqptype] = []
                    for tool in tools:
                        if tool not in dict_eqptype_to_tools_active[eqptype]:
                            dict_eqptype_to_tools_active[eqptype].append(tool)

    return dict_eqptype_to_tools_active