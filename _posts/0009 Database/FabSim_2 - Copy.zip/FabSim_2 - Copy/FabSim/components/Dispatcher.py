from .Lot import Lot
import numpy as np
import logging
import copy
import time

class Dispatcher:
    """Dispatcher is the class that dispatches lots to the fab.

    Attributes:
        env:  the simulation environment (simpy.Environment())
        LOTS: [Lot Class]
        FAB:  Fab Class

        dict_prd_to_qty_in_lot
        dict_prd_to_generation_rate_in_lot_per_week

        dict_prd_to_route
        dict_prd_to_steps
        dict_prd_to_valid_steps
        dict_prd_to_step_to_smp_pct
        dict_prd_to_step_to_eqptypes
        dict_prd_to_step_to_eqptype_to_use_pct
        dict_prd_to_step_to_eqptype_to_tool_to_mpu
        dict_prd_to_step_to_eqptype_to_tools
    """
    def __init__(self, env, LOTS, FAB,
                 dict_prd_to_qty_in_lot = {},
                 dict_prd_to_generation_rate_in_lot_per_week = {},
                 dict_prd_to_wafer_num = {},
                 dict_prd_to_priority = {},
                 dict_prd_to_due_time_since_release_in_hour = {},
                 dict_prd_to_route = {},
                 dict_prd_to_steps = {},
                 dict_prd_to_valid_steps = {},
                 dict_prd_to_step_to_smp_pct = {},
                 dict_prd_to_step_to_eqptypes = {},
                 dict_prd_to_step_to_eqptype_to_use_pct = {},
                 dict_prd_to_step_to_eqptype_to_tool_to_mpu = {},
                 dict_prd_to_step_to_eqptype_to_tools = {},
                 dict_prd_to_step_to_eqptype_to_chamber_requirement = {}
                ):
        
        self.env = env
        self.LOTS = LOTS
        self.FAB = FAB

        self.dict_prd_to_qty_in_lot = dict_prd_to_qty_in_lot
        self.dict_prd_to_generation_rate_in_lot_per_week = dict_prd_to_generation_rate_in_lot_per_week
        self.dict_prd_to_wafer_num = dict_prd_to_wafer_num
        self.dict_prd_to_priority = dict_prd_to_priority
        self.dict_prd_to_due_time_since_release_in_hour = dict_prd_to_due_time_since_release_in_hour

        self.dict_prd_to_route = dict_prd_to_route
        self.dict_prd_to_steps = dict_prd_to_steps
        self.dict_prd_to_valid_steps = dict_prd_to_valid_steps

        self.dict_prd_to_step_to_smp_pct = dict_prd_to_step_to_smp_pct

        self.dict_prd_to_step_to_eqptypes = dict_prd_to_step_to_eqptypes
        self.dict_prd_to_step_to_eqptype_to_tool_to_mpu = dict_prd_to_step_to_eqptype_to_tool_to_mpu
        self.dict_prd_to_step_to_eqptype_to_tools = dict_prd_to_step_to_eqptype_to_tools
        self.dict_prd_to_step_to_eqptype_to_use_pct = dict_prd_to_step_to_eqptype_to_use_pct
        self.dict_prd_to_step_to_eqptype_to_chamber_requirement = dict_prd_to_step_to_eqptype_to_chamber_requirement



    def run(self):
        # (1) Dispatch once
        if self.dict_prd_to_qty_in_lot != {} and self.dict_prd_to_generation_rate_in_lot_per_week == {}:
            lot_id = 0
            for prd in self.dict_prd_to_qty_in_lot:
                qty = self.dict_prd_to_qty_in_lot[prd]
                for i in range(qty):
                    self.dispatch(lot_id, prd, wafer_num=self.dict_prd_to_wafer_num[prd])
                    lot_id += 1
        # (2) Dispatch continuously
        elif self.dict_prd_to_qty_in_lot == {} and self.dict_prd_to_generation_rate_in_lot_per_week != {}:
            dict_prd_to_qty_in_lot_per_hour = {prd: self.dict_prd_to_generation_rate_in_lot_per_week[prd]/(24*7)  \
                                                    for prd in self.dict_prd_to_generation_rate_in_lot_per_week.keys()}
            dict_prd_to_qty_in_lot_accum = {prd: 0 for prd in dict_prd_to_qty_in_lot_per_hour.keys()}

            # (2.1) Dispatch the lots in the first week, which are what we care about
            #   those lots will be added into LOTS list for recording purpose
            for i in range(7*24):
                for prd in dict_prd_to_qty_in_lot_per_hour.keys():
                    dict_prd_to_qty_in_lot_accum[prd] += dict_prd_to_qty_in_lot_per_hour[prd]
                    if dict_prd_to_qty_in_lot_accum[prd] >= 1:
                        dict_prd_to_qty_in_lot_accum[prd] -= 1
                        self.dispatch(str(time.time()), prd, wafer_num=self.dict_prd_to_wafer_num[prd])
                        logging.info(f"Dispatched a lot of {prd} at time {self.env.now}")
                yield self.env.timeout(1)

            # (2.2) Dispatch the lots after the first week
            while True:
                for prd in dict_prd_to_qty_in_lot_per_hour.keys():
                    dict_prd_to_qty_in_lot_accum[prd] += dict_prd_to_qty_in_lot_per_hour[prd]
                    if dict_prd_to_qty_in_lot_accum[prd] >= 1:
                        dict_prd_to_qty_in_lot_accum[prd] -= 1
                        # For the lots dispatching after the first week, the ID is set to -1
                        self.dispatch(-1, prd, wafer_num=self.dict_prd_to_wafer_num[prd], is_first_week=False)
                        logging.info(f"Dispatched a lot of {prd} at time {self.env.now}")
                yield self.env.timeout(1)
        else:
            raise Exception("Inputs dict_prd_to_qty_in_lot_per_hour and dict_prd_to_generation_rate_in_lot_per_week cannot be both empty or non-empty!")



    def dispatch(self, id, prd, wafer_num = 20, is_first_week=True):
        lot = Lot(self.env, id, prd,
            route       = self.dict_prd_to_route[prd],
            wafer_num   = wafer_num,
            steps       = self.dict_prd_to_steps[prd],
            valid_steps = self.dict_prd_to_valid_steps[prd],
            dict_step_to_smp_pct             = self.dict_prd_to_step_to_smp_pct[prd],
            dict_step_to_eqptypes            = self.dict_prd_to_step_to_eqptypes[prd],
            dict_step_to_eqptype_to_use_pct  = self.dict_prd_to_step_to_eqptype_to_use_pct[prd],
            dict_step_to_eqptype_to_tool_to_mpu      = self.dict_prd_to_step_to_eqptype_to_tool_to_mpu[prd],
            dict_step_to_eqptype_to_tools    = self.dict_prd_to_step_to_eqptype_to_tools[prd],
            dict_step_to_eqptype_to_chamber_requirement = self.dict_prd_to_step_to_eqptype_to_chamber_requirement[prd],
            priority           = self.dict_prd_to_priority[prd],
            start_time_in_hour = self.env.now,
            due_time_in_hour   = self.env.now+self.dict_prd_to_due_time_since_release_in_hour[prd]
        )
        # only the lots starting in the first week will be added to the LOTS list for recording
        if is_first_week:
            self.LOTS.append(lot)
        #TODO: report the multiple eqp_types problem，如果发现有多个eqp_type可以运行
        step = lot.valid_steps[lot.cur_step_num]
        next_eqptype_name = None
        next_eqptype_names = copy.deepcopy(list(lot.dict_step_to_eqptype_to_tools[step].keys()))
        if len(next_eqptype_names) == 1:
            next_eqptype_name = next_eqptype_names[0]
        else:
            next_use_pcts = [lot.dict_step_to_eqptype_to_use_pct[step][eqptype_name] for eqptype_name in next_eqptype_names]
            next_probs = np.array(next_use_pcts) / np.sum(next_use_pcts)
            next_eqptype_name = np.random.choice(next_eqptype_names, p=next_probs)

        self.FAB.eqptypes[next_eqptype_name].scheduler.put_lot_into_reservation((lot, lot.cur_step_num))



    def dispatch_init(self, LOTS_init, dict_init_prd_to_step_to_wafer_nums={}):
        for prd in dict_init_prd_to_step_to_wafer_nums:
            for step in dict_init_prd_to_step_to_wafer_nums[prd]:
                if step in self.dict_prd_to_valid_steps[prd]:
                    cur_step_num = self.dict_prd_to_valid_steps[prd].index(step)
                    step = self.dict_prd_to_valid_steps[prd][cur_step_num]
                    for wafer_num in dict_init_prd_to_step_to_wafer_nums[prd][step]:
                        lot = Lot(self.env, id = -1, prd = prd,
                            route = self.dict_prd_to_route[prd],
                            wafer_num = wafer_num,
                            steps = self.dict_prd_to_steps[prd],
                            valid_steps = self.dict_prd_to_valid_steps[prd],
                            dict_step_to_smp_pct  = self.dict_prd_to_step_to_smp_pct[prd],
                            dict_step_to_eqptypes = self.dict_prd_to_step_to_eqptypes[prd],
                            dict_step_to_eqptype_to_use_pct = self.dict_prd_to_step_to_eqptype_to_use_pct[prd],
                            dict_step_to_eqptype_to_tool_to_mpu = self.dict_prd_to_step_to_eqptype_to_tool_to_mpu[prd],
                            dict_step_to_eqptype_to_tools = self.dict_prd_to_step_to_eqptype_to_tools[prd],
                            dict_step_to_eqptype_to_chamber_requirement = self.dict_prd_to_step_to_eqptype_to_chamber_requirement[prd]
                        )
                        #TODO: 之后在这考虑加入 priority，在wip_real_time中应该就有
                        lot.init_step_num = cur_step_num
                        lot.last_assigned_step_num = cur_step_num
                        lot.cur_step_num  = cur_step_num
                        lot.due_time_in_hour = self.env.now + 2160 * (lot.final_step_num - lot.cur_step_num) / lot.final_step_num

                        next_eqptype_name = None
                        next_eqptype_names = copy.deepcopy(list(lot.dict_step_to_eqptype_to_tools[step].keys()))
                        if len(next_eqptype_names) == 1:
                            next_eqptype_name = next_eqptype_names[0]
                        else:
                            next_use_pcts = [lot.dict_step_to_eqptype_to_use_pct[step][eqptype_name] for eqptype_name in next_eqptype_names]
                            next_probs = np.array(next_use_pcts) / np.sum(next_use_pcts)
                            next_eqptype_name = np.random.choice(next_eqptype_names, p=next_probs)

                        self.FAB.eqptypes[next_eqptype_name].scheduler.put_lot_into_reservation((lot, lot.cur_step_num))