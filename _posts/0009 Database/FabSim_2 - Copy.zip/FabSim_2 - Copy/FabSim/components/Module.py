import numpy as np

class Module:
    """Module
    
    Attributes:
        env:         the simulation environment (simpy.Environment())
        name:        
        eqptypes:    {eqptype_name: Eqptype Class}
    """
    def __init__(self, env, name="", eqptypes={}):
        self.env = env
        self.name = name
        self.eqptypes = eqptypes


        # (1) WIP diagram
        # the following attributes are used to draw the WIP diagram
        self.qty_in_lot_in_process = 0
        self.qty_in_lot_in_queue = 0
        self.qty_in_lot_in_process_HIST = []
        self.qty_in_lot_in_queue_HIST = []
        self.time_HIST = []

        # (2) Average Queuing Time
        self.avg_queue_time = 0

        self.dict_eqptype_to_tools_to_utilizations = {eqptype.name: {tool_name: {} for tool_name in eqptype.tools} for eqptype in eqptypes.values()}
        self.dict_eqptype_to_utilizations = {eqptype_name: {} for eqptype_name in eqptypes}
        self.dict_utilizations = {}


    def update_wip_and_avg_queue_time(self, ifFIFO=True):
        # (1) WIP
        qty_in_lot_in_process = 0
        qty_in_lot_in_queue = 0
        # (2) Average Queue Time
        total_queue_time = 0
        count = 0

        for eqptype in self.eqptypes.values():
            with eqptype.scheduler.reservation_R.request() as req:
                for lot, step_num in eqptype.scheduler.reservation:
                    if lot.cur_step_num == step_num:
                        qty_in_lot_in_queue += 1
                for tool in eqptype.tools.values():
                    for lot, step_num in tool.queue:
                        if lot.cur_step_num == step_num:
                            qty_in_lot_in_queue += 1
                
            for tool in eqptype.tools.values():
                if tool.has_chambers:
                    if tool.lot_in_waiting is not None:
                        qty_in_lot_in_queue += 1
                    lots_in_process = []
                    for ch in tool.chambers:
                        if ch.lot_in_process is not None:
                            if ch.lot_in_process not in lots_in_process:
                                lots_in_process.append(ch.lot_in_process)
                    qty_in_lot_in_process += len(lots_in_process)
                else:
                    if tool.lot_in_process is not None:
                        qty_in_lot_in_process += 1

                total_queue_time += sum(tool.queue_times)
                count += len(tool.queue_times)

        self.qty_in_lot_in_process = qty_in_lot_in_process
        self.qty_in_lot_in_queue = qty_in_lot_in_queue
        self.qty_in_lot_in_process_HIST.append(self.qty_in_lot_in_process)
        self.qty_in_lot_in_queue_HIST.append(self.qty_in_lot_in_queue)
        self.time_HIST.append(round(self.env.now, 1))

        self.avg_queue_time = total_queue_time / count if count != 0 else 0


    def update_utilization(self):
        # run each 10 hour
        time_range_start = self.env.now - 10
        time_range_end = self.env.now

        eqptype_utilizations = []
        for eqptype_name in self.eqptypes:
            eqptype = self.eqptypes[eqptype_name]

            tool_utilizations = []
            for tool_name in eqptype.tools:
                tool = eqptype.tools[tool_name]

                # production_time = 0
                production_time_ranges = []
                for i in range(int(tool.ptr_pointer), len(tool.process_time_ranges)):
                    start, end = tool.process_time_ranges[i]
                    if start >= time_range_start and end <= time_range_end:
                        # production_time += end - start
                        production_time_ranges.append([start, end])
                        tool.ptr_pointer += 1
                    elif start < time_range_start and end > time_range_start:
                        # production_time += end - time_range_start 
                        production_time_ranges.append([time_range_start, end])
                        tool.ptr_pointer += 0.5
                    elif start < time_range_end and end > time_range_end:
                        # production_time += time_range_end - start
                        production_time_ranges.append([start, time_range_end])
                        tool.ptr_pointer += 0.5
                    else:
                        pass
                
                production_time_ranges_effective = self.combine_ranges(production_time_ranges)
                production_time = sum([end - start for start, end in production_time_ranges_effective])
    
                tool_utilizations.append(production_time / 10)
                self.dict_eqptype_to_tools_to_utilizations[eqptype_name][tool_name][time_range_end] = production_time / 10
            
            eqptype_utilizations.append(np.mean(tool_utilizations))
            self.dict_eqptype_to_utilizations[eqptype_name][time_range_end] = np.mean(tool_utilizations)

        self.dict_utilizations[time_range_end] = np.mean(eqptype_utilizations)

    def run_wip_and_avg_queue_time(self):
        while True:
            self.update_wip_and_avg_queue_time()
            yield self.env.timeout(2)


    def run_utilization(self):
        while True:
            yield self.env.timeout(10)
            self.update_utilization()


    def run(self):
        self.env.process(self.run_wip_and_avg_queue_time())
        self.env.process(self.run_utilization())

    def combine_two_ranges(self, range1, range2):
        # Ranges do not overlap
        if range1[1] < range2[0] or range2[1] < range1[0]:
            return [range1, range2]
        
        # Ranges overlap, combine  
        start = min(range1[0], range2[0])
        end = max(range1[1], range2[1])
        return [[start, end]]
    
    def combine_ranges(self, ranges):
        rgs_output = []
        for i in range(len(ranges)):
            if i == 0:
                rgs_output.append(ranges[i])
            else:
                for j in range(len(rgs_output)):
                    rgs_new = self.combine_two_ranges(ranges[i], rgs_output[j])
                    if len(rgs_new) == 1: # combine successfully
                        rgs_output[j] = rgs_new[0]
                        break
                    else: # cannot combine, if rgs_output[j] is the last try, then append ranges[i] to rgs_output
                        if j == len(rgs_output) - 1:
                            rgs_output.append(ranges[i])
                        else:
                            pass
        # while checkoverlap(rgs) == False:
        #   rgs = cb(rgs)
        return rgs_output
    
    # def checkoverlap(ranges):
    #     for i in range(len(ranges)):
    #         rg1 = ranges[i]
    #         for j in range(i+1, len(ranges)):
    #             rg2 = ranges[j]
    #             if rg1[1] < rg2[0] or rg2[1] < rg1[0]:
    #                 pass
    #             else:
    #                 return False
    #     return True
