import numpy as np
from .Module import Module


class Factory:
    """Factory

    Model the fab

    Attributes:
        env:              the simulation environment (simpy.Environment())
        eqptypes:         {eqptype_name: Eqptype Class}
        enable_animation: if to run the animation
        modules:          {module_name: Module Class}
    """
    def __init__(self,
                 env, 
                 eqptypes=[],
                 dict_eqptype_to_module={},
                 enable_animation=False,
        ):
        
        self.env = env
        self.eqptypes = eqptypes
        self.enable_animation = enable_animation



        # set up Module
        self.modules = {}
        dict_module_to_eqptypes = {}
        for eqptype in self.eqptypes.values():
            eqptype_name = eqptype.name
            module_name = dict_eqptype_to_module[eqptype_name]
            if module_name != 'NA':
                if module_name not in dict_module_to_eqptypes:
                    dict_module_to_eqptypes[module_name] = []
                dict_module_to_eqptypes[module_name].append(eqptype_name)
        for module_name in dict_module_to_eqptypes:
            self.modules[module_name] = Module(env, module_name, {eqptype_name: self.eqptypes[eqptype_name] for eqptype_name in dict_module_to_eqptypes[module_name]})



    def run(self):
        for f in self.eqptypes.values():
            self.env.process(f.scheduler.run())
            f.run_tools(self)
        
        # Since Module Class currently is only related to animation
        # if we don't need to run the animation, we don't need to create any module, so that save time
        if self.enable_animation:
            for m in self.modules.values():
                m.run()
