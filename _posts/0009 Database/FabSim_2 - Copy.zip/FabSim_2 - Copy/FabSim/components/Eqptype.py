import simpy
import numpy as np
import copy
from ..schedulers.Scheduler import Scheduler

class Eqptype:
    """Eqptype

    Model a Eqptype (equipment type) in a factory

    Attributes:
        env:       the simulation environment (simpy.Environment())
        name:
        tools:  {tool_name: Tool Class}
        reservation:   [(Lot Class, step)], containing the (lot, step) that should be reserved, for example,
                                            (Lot_1, 5) means the 5th step of Lot_1 should be reserved
        reservation_R: a mutex lock
    """
    def __init__(self, env, name="", tools={}, scheduler=Scheduler):
        self.env = env
        self.name = name
        self.tools = tools

        self.scheduler = scheduler(env, eqptype_name=self.name, tools=tools)



    def run_tools(self, FAB):
        '''Run all Entities in this Eqptype
        '''
        for et in self.tools.values():
            if et.has_chambers:
                self.env.process(et.run_with_chambers(self.name, FAB))
            else:
                self.env.process(et.run(self.name, FAB))






