

class Chamber:
    def __init__(self, env, name="", type=""):
        self.env = env
        self.name = name
        self.type = type

        self.lot_in_process = None



    def process(self, lot, process_time_in_hour, chambers, tool, FAB):
        if lot.is_in_process == True:
            raise Exception('Lot assigned to chamber is already in process!')
        else:
            lot.is_in_process = True
        self.lot_in_process = lot
        for ch in chambers:
            ch.lot_in_process = lot
        
        # (1) Pre-process
        #   If the lot is at the last step, then calculate its cycle time
        #   Else, assign Lot to the reservations of its serveral next steps
        if lot.cur_step_num == lot.final_step_num:
            lot.cycle_time = self.env.now - lot.start_time_in_hour + process_time_in_hour
        else:
            tool.assign_lot_to_next_reservations(lot, FAB)

        #   Calculate the queuing time of the current lot
        if lot.cur_step_num != lot.init_step_num:
            tool.queue_times.append(self.env.now - lot.progress[-1][-1])


        # (2) Processing
        tool.process_time_ranges += [(self.env.now, self.env.now + process_time_in_hour)]
        time_start = self.env.now
        yield self.env.timeout(process_time_in_hour)
        time_end = self.env.now

        step = lot.valid_steps[lot.cur_step_num]
        lot.progress.append([tool.name, lot.cur_step_num, step, time_start, time_end])

        # (3) Post-process
        lot.cur_step_num += 1
        lot.is_in_process = False
        #   Make Tool become free (it could process another Lot)
        self.lot_in_process = None
        for ch in chambers:
            ch.lot_in_process = None