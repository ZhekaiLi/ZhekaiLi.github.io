from .Chamber import Chamber

import numpy as np
import simpy
import copy

class Tool:
    """Entity

    Attributes:
        name: the name of the tool

        dict_recp_to_MPU: {recipe: MPU}
        initScores:       {recipe: initial_score = 1/MPU}
        scores:           {recipe: score}

        queue:          [Lot], the lots waiting in the queue
        lot_in_process: Lot,   the lot that is in process
        queue_times:    [float], every time when a lot goes into process, its queuing time will be recorded
    """
    def __init__(self, env, name="", dict_chamber_type_to_count={}):
        self.env = env
        self.name = name
        if dict_chamber_type_to_count == {}:
            self.has_chambers = False
        else:
            self.dict_chamber_type_to_count = copy.deepcopy(dict_chamber_type_to_count)
            self.has_chambers = True
            self.chambers = []
            for ch_type in self.dict_chamber_type_to_count:
                for i in range(self.dict_chamber_type_to_count[ch_type]):
                    self.chambers.append(Chamber(env, name=ch_type+"_"+str(i), type=ch_type))

        self.init_score = 1
        self.score = self.init_score

        self.queue = []
        self.queue_R = simpy.Resource(env=self.env, capacity=1)
        self.lot_in_process = None
        self.lot_in_waiting = None

        self.queue_times = []
        self.process_time_ranges = []

        self.ptr_pointer = 0

    def __str__(self):
        #TODO: 每个类都应该有这个功能
        print("Class: Entity")
        print("Name: " + self.name)
        print("Recipe to MPU: " + str(self.dict_recp_to_MPU))
        return "Scores: " + str(self.scores)

    def update_score(self):
        self.score = self.init_score - len(self.queue)

    def run(self, eqptype_name, FAB):
        while True:
            # Entity will run if NO Lot is processing now
            if self.lot_in_process is None:
                # (1) Choose the first Lot that is not in process
                should_pick = False
                with self.queue_R.request() as req:
                    yield req
                    for i in range(len(self.queue)):
                        lot, step_num = self.queue[i]
                        # means that the Lot should be processed in the current Eqptype
                        if lot.cur_step_num == step_num:
                            # Delete Lot from Entity.queue, Eqptype.reservation
                            self.lot_in_process = lot
                            del self.queue[i]
                            self.update_score()

                            should_pick = True
                            break
                    # reservation_R is released

                # (2) Process Lot
                if should_pick:
                    lot = self.lot_in_process
                    if lot.is_in_process == True:
                        raise Exception('Lot assigned to tool is already in process!')
                        exit()
                    else:
                        lot.is_in_process = True
                    #TODO: Sampling could be modeled more close to the real case
                    cur_step = lot.valid_steps[lot.cur_step_num]
                    process_time_in_hour = lot.dict_step_to_eqptype_to_tool_to_mpu[cur_step][eqptype_name][self.name] * lot.wafer_num \
                        * lot.dict_step_to_smp_pct[cur_step] / 60


                    # (1) Pre-process
                    #   If the lot is at the last step, then calculate its cycle time
                    #   Else, assign Lot to the reservations of its serveral next steps
                    if lot.cur_step_num == lot.final_step_num:
                        lot.cycle_time = self.env.now - lot.start_time_in_hour + process_time_in_hour
                    else:
                        self.assign_lot_to_next_reservations(lot, FAB)

                    #   Calculate the queuing time of the current lot
                    if lot.cur_step_num != lot.init_step_num:
                        self.queue_times.append(self.env.now - lot.progress[-1][-1])


                    # (2) Processing
                    self.process_time_ranges += [(self.env.now, self.env.now + process_time_in_hour)]
                    time_start = self.env.now
                    yield self.env.timeout(process_time_in_hour)
                    time_end = self.env.now

                    lot.progress.append([self.name, lot.cur_step_num, cur_step, time_start, time_end])

                    # (3) Post-process
                    lot.cur_step_num += 1
                    lot.is_in_process = False
                    #   Make Entity become free (it could process another Lot)
                    self.lot_in_process = None

            # wait for 1.5 min (0.025 hour)
            yield self.env.timeout(0.025)



    def assign_lot_to_next_reservations(self, lot, FAB):
        '''Assign the lot in process to the reservations of its next few steps

        :param fab: the factory object
        '''
        # Assign to the next five steps
        lasn = lot.last_assigned_step_num
        for next_step_num in range(lasn+1, lasn+7):
            if next_step_num > lot.final_step_num:
                break

            if next_step_num > lot.cur_step_num + 5:
                break

            lot.last_assigned_step_num = next_step_num
            next_step = lot.valid_steps[next_step_num]
            next_eqptype_name = None
            next_eqptype_names = copy.deepcopy(list(lot.dict_step_to_eqptype_to_tools[next_step].keys()))
            if len(next_eqptype_names) == 1:
                next_eqptype_name = next_eqptype_names[0]
            else:
                next_use_pcts = [lot.dict_step_to_eqptype_to_use_pct[next_step][eqptype_name] for eqptype_name in next_eqptype_names]
                next_probs = np.array(next_use_pcts) / np.sum(next_use_pcts)
                next_eqptype_name = np.random.choice(next_eqptype_names, p=next_probs)

            # DO NOT assign if the lot is already in the queue
            #     NO need to check if the lot is already in the reservation or not
            #     because the function Scheduler.put_lot_into_reservation() below will check it
            
            # define a varaible to determine if to add the lot into the reservation
            # add_to_reservation = True
            # for tool in FAB.eqptypes[next_eqptype_name].tools.values():
            #     if (lot, next_step_num) in tool.queue:
            #         add_to_reservation = False
            #         break
            #     if tool.has_chambers == True:
            #         if (lot, next_step_num) == tool.lot_in_waiting:
            #             add_to_reservation = False
            #             break
            #         else:
            #             pairs = [(ch.lot_in_process, ch.lot_in_process.cur_step_num) for ch in tool.chambers if ch.lot_in_process != None]
            #             if (lot, next_step_num) in pairs:
            #                 add_to_reservation = False
            #                 break

            
            # if add_to_reservation:
            #     #TODO: 这里还是用不了 mutex lock
            #     # with fab.eqptypes[next_eqptype_name].reservation_R.request() as req:
            #     #     yield req
            FAB.eqptypes[next_eqptype_name].scheduler.put_lot_into_reservation((lot, next_step_num))



    def check_chambers_availability(self, chamber_requirement, dict_chamber_type_to_count):
        '''Check if there are enough available chambers to process the Lot
        '''
        for ch_type in chamber_requirement:
            a = chamber_requirement[ch_type]
            b = dict_chamber_type_to_count[ch_type]
            if chamber_requirement[ch_type] > dict_chamber_type_to_count[ch_type]:
                return False
        return True



    def send_lot_to_chambers(self, lot, step, chamber_requirement, dict_chamber_type_to_count, eqptype_name, FAB):
        ch_requirement = copy.deepcopy(chamber_requirement)
        chs_to_be_sent = []
        for ch in self.chambers:
            if (ch.lot_in_process == None) and (ch.type in ch_requirement):
                if ch_requirement[ch.type] > 0:
                    chs_to_be_sent.append(ch)
                    ch_requirement[ch.type] -= 1
                    dict_chamber_type_to_count[ch.type] -= 1

        process_time_in_hour = lot.dict_step_to_eqptype_to_tool_to_mpu[step][eqptype_name][self.name] * lot.wafer_num \
                * lot.dict_step_to_smp_pct[step] / 60
        ch_main = chs_to_be_sent[0]
        if len(chs_to_be_sent) == 1:
            self.env.process(ch_main.process(lot, process_time_in_hour, [], self, FAB))
        else: # len(chambers_to_send) > 1
            # if all chambers are the same type, then divide the process_time_in_hour
            #   for example for '2COAT', divide the process_time_in_hour by 2

            ch_types_to_be_sent = [ch.type for ch in chs_to_be_sent]
            if ch_types_to_be_sent.count(ch_types_to_be_sent[0]) == len(ch_types_to_be_sent):
                process_time_in_hour /= len(chs_to_be_sent)
            # if the chambers are not the same type, then keep the process_time_in_hour
            #   for example for '1POLY+1COAT', keep the process_time_in_hour
            self.env.process(ch_main.process(lot, process_time_in_hour, chs_to_be_sent[1:], self, FAB))



    def run_with_chambers(self, eqptype_name, FAB):
        '''Run the Entity that belongs to this Eqptype
        '''
        while True:
            # et.chambers = [ch1(poly), ch2(poly), ch3(coat), ch4(devlp)]
            # et.dict_chamber_type_to_count = {poly: 2, coat: 1, devlp: 1}
            # et.lot_in_waiting = lot1

            # run the tool if there is any chamber that is not processing any lot
            if any([ch.lot_in_process == None for ch in self.chambers]):
                # get the updated dict_chamber_type_to_count
                dict_ch_type_to_count = copy.deepcopy(self.dict_chamber_type_to_count)
                for ch in self.chambers:
                    if ch.lot_in_process != None:
                        dict_ch_type_to_count[ch.type] -= 1
                # assume ch2(poly) and ch3(coat) are processing Lot
                # then dict_chamber_type_to_count = {poly: 1, coat: 0, devlp: 1}
                
                if self.lot_in_waiting != None:
                    lot, step = self.lot_in_waiting
                    # check is cur_step_num is changed
                    if step != lot.cur_step_num:
                        print(lot.prd, self.name, eqptype_name, step, lot.cur_step_num)
                        exit()
                    else:
                        cur_step = lot.valid_steps[lot.cur_step_num]
                        ch_requirement = copy.deepcopy(lot.dict_step_to_eqptype_to_chamber_requirement[cur_step][eqptype_name])
                        if self.check_chambers_availability(ch_requirement, dict_ch_type_to_count):
                            #TODO: 有一个idea是不要这个函数里边做 env.process, 而是只进行assign操作，然后在函数最后统一process
                            self.send_lot_to_chambers(lot, cur_step, ch_requirement, dict_ch_type_to_count, eqptype_name, FAB)
                            self.lot_in_waiting = None
                # et.lot_in_waiting == None, put the first available lot into the waiting status
                else:
                    with self.queue_R.request() as req:
                        yield req
                        for i in range(len(self.queue)):
                            lot, step_num = self.queue[i]
                            if lot.cur_step_num == step_num:
                                self.lot_in_waiting = (lot, step_num)

                                del self.queue[i]
                                self.update_score()
                                break

                # ITERATE all the other lots in the queue, find any possible to run
                # get the first available lot from the queue
                #TODO: 这里可以考虑取消mutex lock，因为这里的操作只是删除，而在scheduler里面的操作只是添加
                #TODO: 这里的逻辑还是要再考虑一下
                with self.queue_R.request() as req:
                    yield req
                    lot_index_to_add = []
                    for i in range(len(self.queue)):
                        lot, step_num = self.queue[i]
                        # If 
                        if lot.cur_step_num == step_num: # means that the Lot should be processed in the current Eqptype
                            cur_step = lot.valid_steps[step_num]
                            ch_requirement = copy.deepcopy(lot.dict_step_to_eqptype_to_chamber_requirement[cur_step][eqptype_name])
                            if self.check_chambers_availability(ch_requirement, dict_ch_type_to_count):
                                self.send_lot_to_chambers(lot, cur_step, ch_requirement, dict_ch_type_to_count, eqptype_name, FAB)
                                
                                lot_index_to_add.append(i)
                                # If all chambers are occupied, then break
                                if all([ch.lot_in_process != None for ch in self.chambers]):
                                    break
                    for i in lot_index_to_add[::-1]:
                        del self.queue[i]
                    self.update_score()
                            
            # wait for 1.5 min (0.025 hour)
            yield self.env.timeout(0.025)
