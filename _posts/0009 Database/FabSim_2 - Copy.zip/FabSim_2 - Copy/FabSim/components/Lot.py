import numpy as np
import copy
import simpy

class Lot:
    """Lot

    Model a lot that contains several wafers

    Attributes:
        ID:          
        wafer_num:    number of wafers in the lot
        route_name:   name of the route that could be used to process the lot
        route_eqptypes:      [eqptype], a list of equipment types of the route (ordered by the step sequences)
        route_recipes:       [recipe]
        route_tools:         [[tools]]
        dict_step_to_smp_pct: [sampling_rate]
        priority:        priority of the lot
        start_time_in_hour: start time of the lot in hour
        dueTimeInHour:   due time of the lot in hour
        score:           score of the lot, which is a combination of many factors, inlcuding priority and dueTime
                         a high score means that the lot is urgent
        cur_step_num:        the current step of the lot
        final_step_num:      = len(route_eqptypes), the total number of steps of the lot
        progress:        [(toolName, time)], every steps that the lot goes through
        cycle_time:      the completion time (cycle time)
    """

    def __init__(self,
        env, 
        id = None,
        prd = "",
        route = "",
        wafer_num = 20,
        steps = [],
        valid_steps = [],
        dict_step_to_smp_pct  = {},
        dict_step_to_eqptypes = {},
        dict_step_to_eqptype_to_use_pct = {},
        dict_step_to_eqptype_to_tool_to_mpu = {},
        dict_step_to_eqptype_to_tools = {},
        dict_step_to_eqptype_to_chamber_requirement = {},
        priority = 5,
        start_time_in_hour = 0, 
        due_time_in_hour = 1000
        ):
        '''
        The element in route_eqptypes, route_recipes, and route_tools with the same index are relevant
        e.g.:
            route_eqptypes[0]      = the equipment type of the first step \n
            route_recipes[0]       = the recipe of the first step \n
            route_tools[0]         = the list of [tool] that could be used for the recipe of the first step \n
            dict_step_to_smp_pct[0] = the sampling rate of the first step
        '''
        self.env = env
        self.id = id
        self.wafer_num = wafer_num
        self.prd = prd
        self.route= route

        self.steps = copy.deepcopy(steps)
        self.valid_steps = copy.deepcopy(valid_steps)
        self.dict_step_to_smp_pct = copy.deepcopy(dict_step_to_smp_pct)
        self.dict_step_to_eqptypes = copy.deepcopy(dict_step_to_eqptypes)
        self.dict_step_to_eqptype_to_use_pct = copy.deepcopy(dict_step_to_eqptype_to_use_pct)
        self.dict_step_to_eqptype_to_tool_to_mpu = copy.deepcopy(dict_step_to_eqptype_to_tool_to_mpu)
        self.dict_step_to_eqptype_to_tools = copy.deepcopy(dict_step_to_eqptype_to_tools)
        self.dict_step_to_eqptype_to_chamber_requirement = copy.deepcopy(dict_step_to_eqptype_to_chamber_requirement)

        self.priority = priority
        self.start_time_in_hour = start_time_in_hour
        self.due_time_in_hour = due_time_in_hour

        # High score --> Emergent Lot
        self.score = 1/self.priority * (10 - np.log(self.due_time_in_hour))

        self.init_step_num = 0
        self.cur_step_num = 0
        self.final_step_num = len(valid_steps) - 1
        self.last_assigned_step_num = 0

        self.is_in_process = False

        self.progress = []
        self.cycle_time = -1

    def update_score(self, env):
        # expectedTime
        # indicates the time that the lot expected to be in the current step
        # in order to avoid missing dueTime
        expected_time_in_hour = self.cur_step_num/self.final_step_num * (self.due_time_in_hour-self.start_time_in_hour) + \
                             self.start_time_in_hour        

        # if expectedTime > env.now, the lot is early --> low score
        # if expectedTime < env.now, the lot is late  --> high score
        # make calculation simpler
        # self.score = self.priority * np.exp(-(expectedTime - env.now))

        # the max running time cannot be larger than np.log(22000) == 10
        t = env.now
        if expected_time_in_hour >= t:
            self.score = 1/self.priority * (10 - np.log(expected_time_in_hour - t + 1))
        else:
            self.score = 1/self.priority * (10 + np.log(t - expected_time_in_hour + 1))
