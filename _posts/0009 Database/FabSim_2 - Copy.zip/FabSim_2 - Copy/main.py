from FabSim.utils.DataRead import DataRead
from FabSim.utils.DataWrite import DataWrite
from FabSim.utils.getPrdPlan import getPrdPlan
from FabSim.utils.getActiveComps import getActiveComps

from FabSim.components.Dispatcher import Dispatcher
from FabSim.components.Tool import Tool
from FabSim.components.Eqptype import Eqptype
from FabSim.components.Factory import Factory
from FabSim.components.Lot import Lot
from FabSim.components.Module import Module

from FabSim.schedulers.Scheduler import Scheduler
from FabSim.schedulers.Scheduler import Scheduler_FPSScheduler

from FabSim.visualization.tkinterGUI import tkinterGUI_main
from FabSim.visualization.tkinterGUI import tkinterGUI_popup
from FabSim.visualization.plot_gantt_chart import plot_gantt_chart

import argparse
import copy
import cx_Oracle
import datetime
import logging
import os
import pandas as pd
import ruamel.yaml
import shutil
import simpy
import threading
import time
import tkinter as tk
import warnings


def end_simulation(env, event_simulation, run_until=10):
    while True:
        yield env.timeout(1)
        if env.now >= run_until:
            event_simulation.succeed()


if __name__ == "__main__":
    print(os.getcwd())
    os.chdir(os.path.dirname(__file__))
    print(os.getcwd())
    warnings.filterwarnings('ignore')

    parser = argparse.ArgumentParser(description="Fab Simulator") 
    parser.add_argument( '-c','--config-dir', default="config.yaml", help='The config file for setting up the simulator')
    args = parser.parse_args()
    config_dir = args.config_dir 

    with open(config_dir, 'r', encoding='utf8') as f:
        config = ruamel.yaml.safe_load(f)

    # Create the results folder
    counter = 1
    while True:
        folder_dir = f"results/exp_{counter}"
        if not os.path.exists(folder_dir): break
        counter += 1
    os.makedirs(folder_dir, exist_ok=False)

    # Create the logger
    logging.basicConfig(filename=os.path.join(folder_dir, 'log.txt'), level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

    # Edit and save config file into the results folder
    config['experiment_name'] = f"exp_{counter}"
    config['results_dir'] = folder_dir
    with open(os.path.join(config['results_dir'], 'config.yaml'), 'w') as f:
        ruamel.yaml.dump(config, f, Dumper=ruamel.yaml.RoundTripDumper)





    # ------------------------------------------------------------------------------------------------------
    # ------------------------------------------------------------------------------------------------------
    # Read Data
    # ------------------------------------------------------------------------------------------------------
    # ------------------------------------------------------------------------------------------------------
    #TODO: sample valid data need a big update for the new chamber level structure

    # {eqptype: module}
    table_dir = config['read_data']['get_eqptype_to_module']
    dict_eqptype_to_module = DataRead.get_eqptype_to_module(table_dir)

    # {eqptype: [tool]}
    # {tool: eqptype}
    table_dir = config['read_data']['get_eqptype_to_tools_mapping']
    dict_eqptype_to_tools, dict_tool_to_eqptype = DataRead.get_eqptype_to_tools_mapping(table_dir)

    # {eqptype: {tool: [chamber_name]}}
    # {eqptype: {tool: [chamber_type]}}
    # {eqptype: {tool: {chamber_type: count}}}
    table_dir = config['read_data']['get_eqptype_to_tool_to_chamber_MANY']
    dict_eqptype_to_tool_to_chamber_names, \
    dict_eqptype_to_tool_to_chamber_types, \
    dict_eqptype_to_tool_to_chamber_type_to_count \
        = DataRead.get_eqptype_to_tool_to_chamber_MANY()

    # {step: [tool]}
    table_dir = config['read_data']['get_step_to_tools']
    dict_step_to_tools = DataRead.get_step_to_tools(table_dir)

    # {prd: [MANY]}
    table_dir = config['read_data']['get_prd_to_MANY_from']
    dict_prd_to_route, \
    dict_prd_to_steps, \
    dict_prd_to_valid_steps, \
    dict_prd_to_step_to_smp_pct, \
    dict_prd_to_step_to_eqptypes, \
    dict_prd_to_step_to_eqptype_to_use_pct, \
    dict_prd_to_step_to_eqptype_to_mpu, \
    dict_prd_to_step_to_eqptype_to_tools, \
    dict_prd_to_step_to_eqptype_to_chamber_requirement \
        = DataRead.get_prd_to_MANY_from(table_dir, dict_eqptype_to_tools, dict_step_to_tools, dict_eqptype_to_tool_to_chamber_type_to_count)

    # {prd: {step: {tool: MPU}}}
    #TODO: 临时版本，需要优化
    dict_prd_to_step_to_eqptype_to_tool_to_mpu = copy.deepcopy(dict_prd_to_step_to_eqptype_to_tools)
    for prd in dict_prd_to_step_to_eqptype_to_tool_to_mpu:
        for step in dict_prd_to_step_to_eqptype_to_tool_to_mpu[prd]:
            for eqptype in dict_prd_to_step_to_eqptype_to_tool_to_mpu[prd][step]:
                tools = dict_prd_to_step_to_eqptype_to_tools[prd][step][eqptype].copy()
                dict_prd_to_step_to_eqptype_to_tool_to_mpu[prd][step][eqptype] = \
                    {t: dict_prd_to_step_to_eqptype_to_mpu[prd][step][eqptype] for t in tools}

    dict_prd_to_step_to_tool_to_mpu_new = DataRead.get_prd_to_step_to_tool_to_MPU()
    for prd in dict_prd_to_step_to_tool_to_mpu_new:
        for step in dict_prd_to_step_to_tool_to_mpu_new[prd]:
            for tool in dict_prd_to_step_to_tool_to_mpu_new[prd][step]:
                eqptype = dict_tool_to_eqptype[tool]
                try:
                    mpu_new = dict_prd_to_step_to_tool_to_mpu_new[prd][step][tool]
                    dict_prd_to_step_to_eqptype_to_tool_to_mpu[prd][step][eqptype][tool] = mpu_new
                except:
                    pass

    # {init_prd: step: [wafer_num]}]]
    table_dir = config['read_data']['get_route_to_seq_nums_init_from']
    dict_init_prd_to_step_to_wafer_nums = DataRead.get_init_prd_to_step_to_wafer_nums(table_dir, dict_prd_to_valid_steps=dict_prd_to_valid_steps)
    
    # {product: quantity_in_wafer}
    # This data are usually not from database, but from the user's input
    dict_prd_to_qty_in_wafer = []

    table_dir = config['read_data']['get_prd_to_PLAN']
    dict_prd_to_PLAN = DataRead.get_prd_to_PLAN(table_dir, valid_prds=list(dict_prd_to_route.keys()))
    print(dict_prd_to_PLAN)

    # Save the used input data to the results folder
    for func_name in config['read_data'].keys():
        if func_name[:3] == 'get':
            try:
                table_dir = config['read_data'][func_name] # data/...
                dst_dir = f"{config['results_dir']}/data_inputs/{table_dir[5:]}"
                os.makedirs(os.path.dirname(dst_dir), exist_ok=True)
                shutil.copy(table_dir, dst_dir)
            except:
                pass



    # ------------------------------------------------------------------------------------------------------
    # ------------------------------------------------------------------------------------------------------
    # Pre-Simulation: Build Fab's Components
    # ------------------------------------------------------------------------------------------------------
    # ------------------------------------------------------------------------------------------------------

    # (1) Get the active components (eqptypes and tools) needed to be modeled
    #   because some components are noed used but still in the horical data, and those things don't need to be modeled
    if config['dispatcher']['input_mode'] == 'once':
        if 'dict_prd_to_PLAN' in locals().keys():
            dict_prd_qty_in_lot = {prd: dict_prd_to_PLAN[prd]['qty'] for prd in dict_prd_to_PLAN}
        else:
            dict_prd_to_qty_in_lot = getPrdPlan(dict_prd_to_qty_in_wafer, size_scaler = config['dispatcher']['size_scaler'])
        prds_active = list(dict_prd_to_qty_in_lot.keys())
    elif config['dispatcher']['input_mode'] == 'generation':
        if 'dict_prd_to_PLAN' in locals().keys():
            dict_prd_to_generation_rate_in_lot_per_week = {prd: dict_prd_to_PLAN[prd]['qty_in_lot'] for prd in dict_prd_to_PLAN}
            print(1)
        else:
            dict_prd_to_generation_rate_in_lot_per_week = getPrdPlan(dict_prd_to_qty_in_wafer, size_scaler = config['dispatcher']['size_scaler'])
        prds_active = list(dict_prd_to_generation_rate_in_lot_per_week.keys())
        for prd in dict_init_prd_to_step_to_wafer_nums:
            if (prd not in prds_active) and (prd in dict_prd_to_route.keys()):
                prds_active.append(prd)
    else:
        raise ValueError("Wrong input_mode in config file, which could only be 'once' or 'generation'")
    
    if config['dispatcher']['input_mode'] == 'once':
        df_production_plan = pd.DataFrame({
            'prd': list(dict_prd_to_qty_in_lot.keys()),
            'qty': list(dict_prd_to_qty_in_lot.values())
        })
    else:
        df_production_plan = pd.DataFrame({
            'prd': list(dict_prd_to_generation_rate_in_lot_per_week.keys()),
            'qty': list(dict_prd_to_generation_rate_in_lot_per_week.values())
        })
    df_production_plan.to_csv(f"{config['results_dir']}/production_plan_active.csv", index=False)

    dict_eqptype_to_tools_active = getActiveComps(prds_active, dict_prd_to_valid_steps, dict_prd_to_step_to_eqptype_to_tools)

    # (2) Create the simulation environment and the event for ending the simulation
    env = simpy.Environment()
    # event_simulation is used to end the simulation, which can be triggered in two cases:
    #   (2.1) when time is larger than config['simulation']['run_until']
    #   (2.2) when the user click the 'End Simulation' button in the GUI
    event_simulation = env.event()

    # (3) Create Tool, Eqptype, and Factory objects
    eqptypes = {} # {eqptype_name: Eqptype}
    dict_scheduler_name_to_scheduler_class = {'Scheduler': Scheduler, 'Scheduler_FPSScheduler': Scheduler_FPSScheduler}
    for eqptype_name in dict_eqptype_to_tools_active:
        tools = {}
        for tool_name in dict_eqptype_to_tools_active[eqptype_name]:
            # Check if the tool contains chambers
            if eqptype_name in dict_eqptype_to_tool_to_chamber_type_to_count.keys():
                if tool_name in dict_eqptype_to_tool_to_chamber_type_to_count[eqptype_name].keys():
                    dict_chamber_type_to_count = dict_eqptype_to_tool_to_chamber_type_to_count[eqptype_name][tool_name]
                    tools[tool_name] = Tool(env, name=tool_name, dict_chamber_type_to_count=dict_chamber_type_to_count)
                else:
                    tools[tool_name] = Tool(env, name=tool_name)
            else:
                tools[tool_name] = Tool(env, name=tool_name)

        if eqptype_name in config['scheduler'].keys():
            scheduler_class = dict_scheduler_name_to_scheduler_class[config['scheduler'][eqptype_name]]
        else:
            scheduler_class = dict_scheduler_name_to_scheduler_class[config['scheduler']['default']]
        eqptypes[eqptype_name] = Eqptype(env, name=eqptype_name, tools=tools, scheduler=scheduler_class)
    FAB = Factory(env, eqptypes=eqptypes, 
                  dict_eqptype_to_module=dict_eqptype_to_module, enable_animation=config['visualization']['animation'])

    # (4) Create a dispatcher, which is used to dispatch lots
    LOTS = []
    dispatcher = Dispatcher(env, LOTS, FAB,
                            dict_prd_to_wafer_num = {prd: dict_prd_to_PLAN[prd]['wafer_num'] for prd in dict_prd_to_PLAN},
                            dict_prd_to_priority  = {prd: dict_prd_to_PLAN[prd]['priority'] for prd in dict_prd_to_PLAN},
                            dict_prd_to_due_time_since_release_in_hour = {prd: dict_prd_to_PLAN[prd]['due_time_since_release_in_hour'] for prd in dict_prd_to_PLAN},
                            dict_prd_to_route            = dict_prd_to_route,
                            dict_prd_to_steps            = dict_prd_to_steps,
                            dict_prd_to_valid_steps      = dict_prd_to_valid_steps,
                            dict_prd_to_step_to_smp_pct  = dict_prd_to_step_to_smp_pct,
                            dict_prd_to_step_to_eqptypes = dict_prd_to_step_to_eqptypes,
                            dict_prd_to_step_to_eqptype_to_use_pct             = dict_prd_to_step_to_eqptype_to_use_pct,    
                            dict_prd_to_step_to_eqptype_to_tool_to_mpu         = dict_prd_to_step_to_eqptype_to_tool_to_mpu,
                            dict_prd_to_step_to_eqptype_to_tools               = dict_prd_to_step_to_eqptype_to_tools,
                            dict_prd_to_step_to_eqptype_to_chamber_requirement = dict_prd_to_step_to_eqptype_to_chamber_requirement
    )
    if config['dispatcher']['input_mode'] == 'once':
        dispatcher.dict_prd_to_qty_in_lot = dict_prd_to_qty_in_lot
    elif config['dispatcher']['input_mode'] == 'generation':
        dispatcher.dict_prd_to_generation_rate_in_lot_per_week = dict_prd_to_generation_rate_in_lot_per_week
        LOTS_init = []
        dispatcher.dispatch_init(LOTS_init, dict_init_prd_to_step_to_wafer_nums=dict_init_prd_to_step_to_wafer_nums)
    else:
        raise ValueError("Wrong input_mode in config file, which could only be 'once' or 'generation'")



    # TODO: reports?
    # sanity check
    # add checking for the data -> report as the problem
    # results
    #     - problems: the problems and the assumed way to solve (python logger?)
    #     - results: statistics, avg utilization of each tools, pictures, 


    # ------------------------------------------------------------------------------------------------------
    # ------------------------------------------------------------------------------------------------------
    # Run Simulation
    # ------------------------------------------------------------------------------------------------------
    # ------------------------------------------------------------------------------------------------------

    # Animation
    #TODO: 可以考虑加入另外两个按钮来控制动画的停止和启动，这样可以控制资源浪费
    #TODO: 同时，目前默认的状态是即使关闭了GUI，程序仍然会继续运行，那么在加入这个功能之后，就可以让程序在GUI被关闭之后停止运行
    if config['visualization']['animation'] == True:
        app = tkinterGUI_main(env, FAB, LOTS, event_simulation)
        thread = threading.Thread(target=app.run)
        thread.start()
        time.sleep(0.1)

    print("----------------------------------------")
    print("Simulation start at {}".format(datetime.datetime.now()))
    # End the simulation when the environment time > run_until
    env.process(end_simulation(env, event_simulation, run_until=config['simulation']['run_until']))
    env.process(dispatcher.run())
    FAB.run()
    env.run(until=event_simulation)

    print("----------------------------------------")
    print("Simulation end at {}".format(datetime.datetime.now()))
    # Edit and save config file into the results folder
    config['simulation']['actual_run_until'] = env.now
    with open(os.path.join(config['results_dir'], 'config.yaml'), 'w') as f:
        ruamel.yaml.dump(config, f, Dumper=ruamel.yaml.RoundTripDumper)

    print("----------------------------------------")
    print("Write results to files...")
    datawrite = DataWrite(LOTS, FAB, results_dir=config['results_dir'])
    for func_name in config['write_data'].keys():
        if config['write_data'][func_name] == True:
            getattr(datawrite, func_name)()
    print("Done.")



    # Plot Result: Gantt Chart of the simulatiom
    if config['visualization']['gantt_chart'] == True:
        if config['dispatcher']['input_mode'] != 'once':
            raise ValueError("Gantt chart is only available for input_mode = 'once'")
        plot_gantt_chart(LOTS, dict_eqptype_to_tools_active, dict_prd_to_qty_in_lot, plot_until=config['simulation']['run_until'])

